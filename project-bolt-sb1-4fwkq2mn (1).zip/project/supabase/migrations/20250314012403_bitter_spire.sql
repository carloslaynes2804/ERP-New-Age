/*
  # Add product line to suppliers

  1. Changes
    - Add product_line column to suppliers table
    - Add index for faster searching by product line

  2. Security
    - No changes to existing policies
*/

-- Add product_line column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'suppliers' 
    AND column_name = 'product_line'
  ) THEN
    ALTER TABLE suppliers ADD COLUMN product_line text;
  END IF;
END $$;

-- Create index for product_line if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'suppliers' 
    AND indexname = 'idx_suppliers_product_line'
  ) THEN
    CREATE INDEX idx_suppliers_product_line ON suppliers(product_line);
  END IF;
END $$;