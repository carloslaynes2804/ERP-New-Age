/*
  # Fix RLS policies for purchase order modifications

  1. Changes
    - Add INSERT policy for purchase order modifications table
    - Allow authenticated users to create modifications
*/

-- Add INSERT policy for purchase order modifications
CREATE POLICY "Users can insert modifications"
  ON purchase_order_modifications
  FOR INSERT
  TO authenticated
  WITH CHECK (true);