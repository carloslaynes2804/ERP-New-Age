/*
  # Create test user and accounts with proper deletion order

  1. Changes
    - Deletes existing user data in correct order to avoid FK violations
    - Creates test user with proper authentication fields
    - Sets up initial bank and cash accounts for the user

  2. Security
    - Password is properly hashed
    - Email is confirmed automatically
    - User has authenticated role
*/

-- First delete all related data in correct order
DO $$
DECLARE
  v_user_id uuid;
BEGIN
  -- Get the user ID first
  SELECT id INTO v_user_id FROM auth.users 
  WHERE email = 'claynes.consultoria@gmail.com' 
  LIMIT 1;

  -- Only proceed with deletions if user exists
  IF v_user_id IS NOT NULL THEN
    -- Delete transactions first as they reference both account types
    DELETE FROM transactions WHERE user_id = v_user_id;
    
    -- Delete budget items
    DELETE FROM budget_items WHERE user_id = v_user_id;
    
    -- Delete bank and cash accounts
    DELETE FROM bank_accounts WHERE user_id = v_user_id;
    DELETE FROM cash_accounts WHERE user_id = v_user_id;
    
    -- Finally delete the user
    DELETE FROM auth.users WHERE id = v_user_id;
  END IF;
END $$;

-- Create test user with proper authentication fields
INSERT INTO auth.users (
  id,
  instance_id,
  email,
  encrypted_password,
  email_confirmed_at,
  raw_app_meta_data,
  raw_user_meta_data,
  created_at,
  updated_at,
  confirmation_token,
  email_change,
  email_change_token_new,
  recovery_token,
  aud,
  role
) VALUES (
  gen_random_uuid(),
  '00000000-0000-0000-0000-000000000000',
  'claynes.consultoria@gmail.com',
  crypt('admin', gen_salt('bf')),
  now(),
  '{"provider":"email","providers":["email"]}',
  '{}',
  now(),
  now(),
  '',
  '',
  '',
  '',
  'authenticated',
  'authenticated'
);

-- Insert initial data for test user
DO $$
DECLARE
  v_user_id uuid;
BEGIN
  SELECT id INTO v_user_id FROM auth.users 
  WHERE email = 'claynes.consultoria@gmail.com' 
  LIMIT 1;

  -- Insert initial bank accounts
  INSERT INTO bank_accounts (name, number, user_id) VALUES
    ('BCP Soles', '193-2458789-0-24', v_user_id),
    ('BBVA Soles', '0011-0124-0100235489', v_user_id),
    ('Interbank Soles', '048-3012458789', v_user_id),
    ('BCP Dólares', '193-2557899-1-35', v_user_id);

  -- Insert initial cash accounts
  INSERT INTO cash_accounts (name, user_id) VALUES
    ('Caja 1', v_user_id),
    ('Caja 2', v_user_id),
    ('Caja 3', v_user_id);
END $$;