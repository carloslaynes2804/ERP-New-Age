/*
  # Add product line constraint to suppliers

  1. Changes
    - Add check constraint to product_line column to limit values to Merchandising, Textil, Imprenta
*/

-- Add check constraint to product_line if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.check_constraints 
    WHERE constraint_name = 'suppliers_product_line_check'
  ) THEN
    ALTER TABLE suppliers 
    ADD CONSTRAINT suppliers_product_line_check 
    CHECK (product_line IN ('Merchandising', 'Textil', 'Imprenta'));
  END IF;
END $$;