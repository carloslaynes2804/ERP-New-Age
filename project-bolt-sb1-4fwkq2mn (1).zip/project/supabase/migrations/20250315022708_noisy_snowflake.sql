/*
  # Fix purchase orders relationship with users

  1. Changes
    - Add foreign key relationship between purchase_orders.created_by and users.id
    - Update existing policies to use the new relationship
    
  2. Security
    - Maintains existing RLS policies
*/

-- Drop existing foreign key if it exists
ALTER TABLE purchase_orders 
DROP CONSTRAINT IF EXISTS purchase_orders_created_by_fkey;

-- Add foreign key relationship to users table
ALTER TABLE purchase_orders
ADD CONSTRAINT purchase_orders_created_by_fkey
FOREIGN KEY (created_by) REFERENCES users(id);

-- Create index for better join performance
CREATE INDEX IF NOT EXISTS idx_purchase_orders_created_by 
ON purchase_orders(created_by);