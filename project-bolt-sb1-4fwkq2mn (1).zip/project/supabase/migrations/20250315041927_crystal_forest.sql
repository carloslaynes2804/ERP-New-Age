/*
  # Fix RLS policies for purchase order original values

  1. Changes
    - Add INSERT policy for purchase_order_original_values table
    - Add UPDATE policy for purchase_order_original_values table
    - Add DELETE policy for purchase_order_original_values table

  2. Security
    - Allow authenticated users to manage original values
    - Maintain data integrity with proper policies
*/

-- Add INSERT policy
CREATE POLICY "Users can insert original values"
  ON purchase_order_original_values
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Add UPDATE policy
CREATE POLICY "Users can update original values"
  ON purchase_order_original_values
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Add DELETE policy
CREATE POLICY "Users can delete original values"
  ON purchase_order_original_values
  FOR DELETE
  TO authenticated
  USING (true);