/*
  # Fix suppliers table RLS policies

  1. Changes
    - Add INSERT policy for suppliers table
    - Update existing SELECT policy to be more specific
    
  2. Security
    - Allow authenticated users to insert new suppliers
    - Maintain read access for authenticated users
*/

-- Drop existing policy if it exists
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'suppliers' 
    AND policyname = 'Users can read suppliers'
  ) THEN
    DROP POLICY "Users can read suppliers" ON suppliers;
  END IF;
END $$;

-- Create comprehensive policies for suppliers
CREATE POLICY "Users can read suppliers"
  ON suppliers
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert suppliers"
  ON suppliers
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update suppliers"
  ON suppliers
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);