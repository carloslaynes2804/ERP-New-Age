/*
  # Fix Payment Obligations Schema

  1. Changes
    - Add missing status column to payment_obligations table
    - Add missing bank column to payment_obligations table
    - Add missing due_date and payment_date columns
    - Update existing constraints and indexes
*/

-- Add missing columns to payment_obligations table
ALTER TABLE payment_obligations
ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'paid', 'cancelled')),
ADD COLUMN IF NOT EXISTS bank text CHECK (bank IN ('BCP', 'Interbank', 'BBVA', 'Scotiabank')),
ADD COLUMN IF NOT EXISTS payment_date date,
ADD COLUMN IF NOT EXISTS due_date date;

-- Create index for status if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_payment_obligations_status') THEN
    CREATE INDEX idx_payment_obligations_status ON payment_obligations(status);
  END IF;
END $$;