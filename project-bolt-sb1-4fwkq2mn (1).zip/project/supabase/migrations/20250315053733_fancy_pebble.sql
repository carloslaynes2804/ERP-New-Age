/*
  # Fix purchase orders display and constraints

  1. Changes
    - Update approval_status constraint to include 'cancelled'
    - Add view for displaying purchase order values
    - Add function to handle original values storage
    
  2. Security
    - Maintains existing RLS policies
*/

-- Drop existing constraint if it exists
DO $$ 
BEGIN
  ALTER TABLE purchase_orders 
  DROP CONSTRAINT IF EXISTS purchase_orders_approval_status_check;
END $$;

-- Add updated constraint
ALTER TABLE purchase_orders 
ADD CONSTRAINT purchase_orders_approval_status_check 
CHECK (approval_status IN ('pending', 'approved', 'rejected', 'cancelled'));

-- Drop existing view if it exists
DROP VIEW IF EXISTS purchase_orders_with_values;

-- Create view for purchase orders with original/current values
CREATE OR REPLACE VIEW purchase_orders_with_values AS
WITH original_values AS (
  SELECT 
    purchase_order_id,
    jsonb_object_agg(field_name, original_value) as original_values
  FROM purchase_order_original_values
  GROUP BY purchase_order_id
)
SELECT 
  po.*,
  CASE 
    WHEN po.approval_status = 'pending' AND ov.original_values IS NOT NULL THEN
      COALESCE(ov.original_values->>'payment_type', po.payment_type)
    ELSE po.payment_type
  END as display_payment_type,
  CASE 
    WHEN po.approval_status = 'pending' AND ov.original_values IS NOT NULL THEN
      COALESCE(ov.original_values->>'currency', po.currency)
    ELSE po.currency
  END as display_currency,
  CASE 
    WHEN po.approval_status = 'pending' AND ov.original_values IS NOT NULL THEN
      COALESCE((ov.original_values->>'total')::numeric, po.total)
    ELSE po.total
  END as display_total
FROM purchase_orders po
LEFT JOIN original_values ov ON ov.purchase_order_id = po.id;

-- Grant access to the view
GRANT SELECT ON purchase_orders_with_values TO authenticated;