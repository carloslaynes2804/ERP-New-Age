/*
  # Create notifications table for approval workflow

  1. New Tables
    - `notifications`
      - Stores notifications for users
      - Used for approval workflows
      - Tracks status and references

  2. Security
    - Enable RLS
    - Add policies for authenticated users
*/

-- Create notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id),
  type text NOT NULL,
  content text NOT NULL,
  reference_id uuid,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'read', 'actioned')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX idx_notifications_user ON notifications(user_id);
CREATE INDEX idx_notifications_status ON notifications(status);
CREATE INDEX idx_notifications_type ON notifications(type);

-- Enable RLS
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read their own notifications"
  ON notifications
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- Add approver_id column to purchase_orders
ALTER TABLE purchase_orders 
ADD COLUMN IF NOT EXISTS approver_id uuid REFERENCES users(id),
ADD COLUMN IF NOT EXISTS approval_status text CHECK (approval_status IN ('pending', 'approved', 'rejected'));