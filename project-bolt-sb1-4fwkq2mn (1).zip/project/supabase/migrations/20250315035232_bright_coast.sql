/*
  # Add Purchase Order Modifications Table

  1. New Tables
    - `purchase_order_modifications`
      - `id` (uuid, primary key)
      - `purchase_order_id` (uuid, foreign key to purchase_orders)
      - `modified_by` (uuid, foreign key to users)
      - `field_name` (text)
      - `old_value` (text)
      - `new_value` (text)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on `purchase_order_modifications` table
    - Add policy for authenticated users to read modifications
*/

-- Create purchase order modifications table
CREATE TABLE IF NOT EXISTS purchase_order_modifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  purchase_order_id uuid NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
  modified_by uuid NOT NULL REFERENCES auth.users(id),
  field_name text NOT NULL,
  old_value text,
  new_value text,
  created_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_modifications_purchase_order ON purchase_order_modifications(purchase_order_id);
CREATE INDEX IF NOT EXISTS idx_modifications_modified_by ON purchase_order_modifications(modified_by);

-- Enable RLS
ALTER TABLE purchase_order_modifications ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read modifications"
  ON purchase_order_modifications
  FOR SELECT
  TO authenticated
  USING (true);

-- Create view for modifications with user details
CREATE OR REPLACE VIEW purchase_order_modifications_with_users AS
SELECT 
  m.*,
  u.display_name as modifier_name
FROM purchase_order_modifications m
JOIN users u ON u.id = m.modified_by;

-- Grant access to the view
GRANT SELECT ON purchase_order_modifications_with_users TO authenticated;