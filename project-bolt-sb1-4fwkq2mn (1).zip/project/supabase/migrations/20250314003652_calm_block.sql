/*
  # Add example suppliers

  1. Changes
    - Add initial example suppliers for testing
    
  2. Security
    - Uses existing RLS policies
*/

-- Insert example suppliers
INSERT INTO suppliers (code, name, tax_id, address, phone, email, payment_terms)
VALUES 
  ('PROV001', 'Comercial San José S.A.C.', '20123456789', 'Av. Industrial 123, Lima', '(01) 555-1234', 'ventas@sanjose.com', 30),
  ('PROV002', 'Distribuidora del Norte E.I.R.L.', '20987654321', 'Jr. Huallaga 456, Lima', '(01) 555-5678', 'ventas@disnorte.com', 15),
  ('PROV003', 'Importaciones Técnicas S.A.', '20456789012', 'Av. Argentina 789, Callao', '(01) 555-9012', 'ventas@imptec.com', 45),
  ('PROV004', 'Suministros Industriales S.A.C.', '20345678901', 'Av. Colonial 321, Lima', '(01) 555-3456', 'ventas@suministros.com', 30),
  ('PROV005', 'Herramientas del Perú S.A.', '20567890123', 'Jr. Paruro 654, Lima', '(01) 555-7890', 'ventas@hdelperu.com', 60)
ON CONFLICT (code) DO NOTHING;