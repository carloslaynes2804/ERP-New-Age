/*
  # Add user roles and permissions

  1. New Tables
    - `user_roles` - Stores user role assignments
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `role` (text) - One of: 'logistics', 'sales', 'finance', 'management'
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on `user_roles` table
    - Add policies for authenticated users
*/

-- Create enum type for roles
DO $$ BEGIN
  CREATE TYPE user_role AS ENUM ('logistics', 'sales', 'finance', 'management');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

-- Create user_roles table
CREATE TABLE IF NOT EXISTS user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role user_role NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, role)
);

-- Enable RLS
ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view their own roles"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Create helper function to check user roles
CREATE OR REPLACE FUNCTION check_user_role(required_role user_role)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = auth.uid()
    AND (role = required_role OR role = 'management')
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;