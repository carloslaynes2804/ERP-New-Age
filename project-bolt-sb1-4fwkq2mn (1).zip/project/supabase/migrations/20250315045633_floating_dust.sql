/*
  # Update modifications view with request grouping

  1. Changes
    - Add modification_group column to track related changes
    - Update view to properly group modifications by request
    - Add index for modification groups

  This migration updates the modifications tracking to properly group
  changes that were made in the same modification request.
*/

-- Add modification_group column
ALTER TABLE purchase_order_modifications
ADD COLUMN IF NOT EXISTS modification_group uuid DEFAULT gen_random_uuid();

-- Add index for modification groups
CREATE INDEX IF NOT EXISTS idx_modifications_group 
ON purchase_order_modifications(modification_group);

-- Drop existing view if it exists
DROP VIEW IF EXISTS purchase_order_modifications_with_users;

-- Recreate view with group information
CREATE VIEW purchase_order_modifications_with_users AS
SELECT 
  m.id,
  m.purchase_order_id,
  m.modified_by,
  m.field_name,
  m.old_value,
  m.new_value,
  m.created_at,
  u.display_name as modifier_name,
  m.modification_group
FROM purchase_order_modifications m
JOIN users u ON u.id = m.modified_by
ORDER BY m.created_at DESC;

-- Grant access to the view
GRANT SELECT ON purchase_order_modifications_with_users TO authenticated;