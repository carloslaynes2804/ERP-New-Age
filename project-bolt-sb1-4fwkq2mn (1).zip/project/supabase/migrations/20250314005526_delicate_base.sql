/*
  # Update suppliers and add bank accounts

  1. Changes
    - Add new fields to suppliers table
    - Create payment_methods table
    - Create supplier_bank_accounts table
    - Add contact information fields
    
  2. Security
    - Enable RLS on new tables
    - Add policies for authenticated users
*/

-- Add new columns to suppliers table
ALTER TABLE suppliers 
ADD COLUMN IF NOT EXISTS website text,
ADD COLUMN IF NOT EXISTS contact_name text,
ADD COLUMN IF NOT EXISTS contact_phone text,
ADD COLUMN IF NOT EXISTS contact_email text,
ADD COLUMN IF NOT EXISTS main_payment_method text CHECK (main_payment_method IN ('bank_deposit', 'yape', 'plin', 'cash')),
ADD COLUMN IF NOT EXISTS mobile_payment_number text;

-- Create supplier_bank_accounts table
CREATE TABLE IF NOT EXISTS supplier_bank_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  supplier_id uuid NOT NULL REFERENCES suppliers(id) ON DELETE CASCADE,
  bank text NOT NULL CHECK (bank IN ('BCP', 'Interbank', 'BBVA', 'Scotiabank')),
  account_number text NOT NULL,
  cci_number text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_supplier_bank_accounts_supplier ON supplier_bank_accounts(supplier_id);

ALTER TABLE supplier_bank_accounts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage supplier bank accounts"
  ON supplier_bank_accounts
  FOR ALL
  TO authenticated
  USING (true);