/*
  # Create Payment Obligations Schema

  1. New Tables
    - `payment_obligations`
      - Header information for payment obligations
      - References to purchase orders
      - Payment details and schedule
    - `payment_obligation_schedule`
      - Payment schedule details
      - Payment amounts and dates

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create payment obligations table
CREATE TABLE IF NOT EXISTS payment_obligations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  number serial UNIQUE NOT NULL,
  date date NOT NULL DEFAULT CURRENT_DATE,
  purchase_order_id uuid NOT NULL REFERENCES purchase_orders(id),
  supplier_id uuid NOT NULL REFERENCES suppliers(id),
  document_type text NOT NULL CHECK (document_type IN ('factura', 'boleta', 'otro')),
  document_date date NOT NULL,
  document_number text NOT NULL,
  concept text NOT NULL,
  observations text,
  obligation_type text NOT NULL CHECK (obligation_type IN ('compras', 'prestamos', 'otros')),
  has_detraction boolean NOT NULL DEFAULT false,
  currency text NOT NULL CHECK (currency IN ('PEN', 'USD')),
  original_amount numeric NOT NULL DEFAULT 0,
  exchange_rate numeric,
  total_amount_pen numeric NOT NULL DEFAULT 0,
  payment_type text NOT NULL CHECK (payment_type IN ('cash', 'credit')),
  payment_method text NOT NULL CHECK (payment_method IN ('bank_deposit', 'yape', 'plin', 'cash')),
  created_by uuid NOT NULL REFERENCES users(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes if they don't exist
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_payment_obligations_number') THEN
    CREATE INDEX idx_payment_obligations_number ON payment_obligations(number);
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_payment_obligations_purchase_order') THEN
    CREATE INDEX idx_payment_obligations_purchase_order ON payment_obligations(purchase_order_id);
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_payment_obligations_supplier') THEN
    CREATE INDEX idx_payment_obligations_supplier ON payment_obligations(supplier_id);
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_payment_obligations_created_by') THEN
    CREATE INDEX idx_payment_obligations_created_by ON payment_obligations(created_by);
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_payment_obligations_date') THEN
    CREATE INDEX idx_payment_obligations_date ON payment_obligations(date);
  END IF;
END $$;

-- Enable RLS
ALTER TABLE payment_obligations ENABLE ROW LEVEL SECURITY;

-- Create policies
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'payment_obligations' 
    AND policyname = 'Users can manage payment obligations'
  ) THEN
    CREATE POLICY "Users can manage payment obligations"
      ON payment_obligations
      FOR ALL
      TO authenticated
      USING (created_by = auth.uid());
  END IF;
END $$;

-- Create payment schedule table
CREATE TABLE IF NOT EXISTS payment_obligation_schedule (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  payment_obligation_id uuid NOT NULL REFERENCES payment_obligations(id) ON DELETE CASCADE,
  payment_number integer NOT NULL CHECK (payment_number BETWEEN 1 AND 4),
  percentage numeric NOT NULL CHECK (percentage > 0 AND percentage <= 100),
  amount_pen numeric NOT NULL DEFAULT 0,
  payment_date date NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(payment_obligation_id, payment_number)
);

-- Create index if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_payment_schedule_obligation') THEN
    CREATE INDEX idx_payment_schedule_obligation ON payment_obligation_schedule(payment_obligation_id);
  END IF;
END $$;

-- Enable RLS
ALTER TABLE payment_obligation_schedule ENABLE ROW LEVEL SECURITY;

-- Create policies
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'payment_obligation_schedule' 
    AND policyname = 'Users can manage payment schedule'
  ) THEN
    CREATE POLICY "Users can manage payment schedule"
      ON payment_obligation_schedule
      FOR ALL
      TO authenticated
      USING (EXISTS (
        SELECT 1 FROM payment_obligations
        WHERE id = payment_obligation_schedule.payment_obligation_id
        AND created_by = auth.uid()
      ));
  END IF;
END $$;

-- Create function for percentage validation
CREATE OR REPLACE FUNCTION validate_payment_schedule_percentages()
RETURNS TRIGGER AS $$
DECLARE
  total_percentage numeric;
BEGIN
  SELECT COALESCE(SUM(percentage), 0)
  INTO total_percentage
  FROM payment_obligation_schedule
  WHERE payment_obligation_id = NEW.payment_obligation_id;

  IF total_percentage > 100 THEN
    RAISE EXCEPTION 'Total percentage cannot exceed 100%%';
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'validate_payment_schedule_percentages_trigger'
  ) THEN
    CREATE TRIGGER validate_payment_schedule_percentages_trigger
      AFTER INSERT OR UPDATE ON payment_obligation_schedule
      FOR EACH ROW
      EXECUTE FUNCTION validate_payment_schedule_percentages();
  END IF;
END $$;