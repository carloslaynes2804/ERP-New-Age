/*
  # Update suppliers table policies

  1. Changes
    - Add DELETE policy for suppliers table
    - Update existing policies to be more specific
    
  2. Security
    - Allow authenticated users to delete suppliers
    - Maintain existing access control for other operations
*/

-- Drop existing policies if they exist
DO $$
BEGIN
  DROP POLICY IF EXISTS "Users can read suppliers" ON suppliers;
  DROP POLICY IF EXISTS "Users can insert suppliers" ON suppliers;
  DROP POLICY IF EXISTS "Users can update suppliers" ON suppliers;
END $$;

-- Create comprehensive policies for suppliers
CREATE POLICY "Users can read suppliers"
  ON suppliers
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert suppliers"
  ON suppliers
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update suppliers"
  ON suppliers
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can delete suppliers"
  ON suppliers
  FOR DELETE
  TO authenticated
  USING (true);