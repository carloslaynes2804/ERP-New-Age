/*
  # Initial Schema Setup and Test User

  1. Tables Created
    - bank_accounts: Store bank account information
    - cash_accounts: Store cash account information
    - transactions: Store financial transactions
    - budget_items: Store budget planning items

  2. Security
    - RLS enabled on all tables
    - Policies for authenticated users
    - Trigger-based referential integrity

  3. Test Data
    - Creates test user (admin/admin)
    - Adds initial bank and cash accounts
*/

-- Create bank_accounts table
CREATE TABLE IF NOT EXISTS bank_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  number text NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE bank_accounts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage their own bank accounts"
  ON bank_accounts
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id);

-- Create cash_accounts table
CREATE TABLE IF NOT EXISTS cash_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE cash_accounts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage their own cash accounts"
  ON cash_accounts
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id);

-- Create transactions table
CREATE TABLE IF NOT EXISTS transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date NOT NULL,
  amount numeric NOT NULL,
  type text NOT NULL CHECK (type IN ('income', 'expense')),
  category text NOT NULL,
  description text NOT NULL,
  document_type text NOT NULL,
  document_number text NOT NULL,
  document_date date NOT NULL,
  account_type text NOT NULL CHECK (account_type IN ('bank', 'cash')),
  sub_account_id uuid NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now()
);

-- Create function to validate transaction account references
CREATE OR REPLACE FUNCTION validate_transaction_account()
RETURNS TRIGGER AS $$
BEGIN
  -- Check if the user owns the referenced account
  IF NEW.account_type = 'bank' THEN
    IF NOT EXISTS (
      SELECT 1 FROM bank_accounts
      WHERE id = NEW.sub_account_id
      AND user_id = NEW.user_id
    ) THEN
      RAISE EXCEPTION 'Invalid bank account reference';
    END IF;
  ELSIF NEW.account_type = 'cash' THEN
    IF NOT EXISTS (
      SELECT 1 FROM cash_accounts
      WHERE id = NEW.sub_account_id
      AND user_id = NEW.user_id
    ) THEN
      RAISE EXCEPTION 'Invalid cash account reference';
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to validate transaction accounts
CREATE TRIGGER validate_transaction_account_trigger
  BEFORE INSERT OR UPDATE ON transactions
  FOR EACH ROW
  EXECUTE FUNCTION validate_transaction_account();

ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage their own transactions"
  ON transactions
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id);

-- Create budget_items table
CREATE TABLE IF NOT EXISTS budget_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date NOT NULL,
  description text NOT NULL,
  amount numeric NOT NULL,
  type text NOT NULL CHECK (type IN ('income', 'expense')),
  is_recurring boolean NOT NULL DEFAULT false,
  status text NOT NULL CHECK (status IN ('pending', 'completed')),
  user_id uuid NOT NULL REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE budget_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage their own budget items"
  ON budget_items
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_transactions_user_date ON transactions(user_id, date);
CREATE INDEX IF NOT EXISTS idx_budget_items_user_date ON budget_items(user_id, date);
CREATE INDEX IF NOT EXISTS idx_bank_accounts_user ON bank_accounts(user_id);
CREATE INDEX IF NOT EXISTS idx_cash_accounts_user ON cash_accounts(user_id);

-- Create test user
INSERT INTO auth.users (
  id,
  instance_id,
  email,
  encrypted_password,
  email_confirmed_at,
  raw_app_meta_data,
  raw_user_meta_data,
  created_at,
  updated_at,
  confirmation_token,
  email_change,
  email_change_token_new,
  recovery_token
) VALUES (
  gen_random_uuid(),
  '00000000-0000-0000-0000-000000000000',
  'admin',
  crypt('admin', gen_salt('bf')),
  now(),
  '{"provider":"email","providers":["email"]}',
  '{}',
  now(),
  now(),
  '',
  '',
  '',
  ''
);

-- Insert initial data for test user
DO $$
DECLARE
  v_user_id uuid;
BEGIN
  SELECT id INTO v_user_id FROM auth.users WHERE email = 'admin' LIMIT 1;

  -- Insert initial bank accounts
  INSERT INTO bank_accounts (name, number, user_id) VALUES
    ('BCP Soles', '193-2458789-0-24', v_user_id),
    ('BBVA Soles', '0011-0124-0100235489', v_user_id),
    ('Interbank Soles', '048-3012458789', v_user_id),
    ('BCP Dólares', '193-2557899-1-35', v_user_id);

  -- Insert initial cash accounts
  INSERT INTO cash_accounts (name, user_id) VALUES
    ('Caja 1', v_user_id),
    ('Caja 2', v_user_id),
    ('Caja 3', v_user_id);
END $$;