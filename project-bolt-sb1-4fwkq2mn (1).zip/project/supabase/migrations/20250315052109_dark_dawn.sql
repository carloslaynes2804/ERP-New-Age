/*
  # Fix purchase order status constraints

  1. Changes
    - Update approval_status check constraint to include 'cancelled'
    - Add cancelled to valid approval statuses
*/

-- Drop existing constraint if it exists
DO $$ 
BEGIN
  ALTER TABLE purchase_orders 
  DROP CONSTRAINT IF EXISTS purchase_orders_approval_status_check;
END $$;

-- Add updated constraint
ALTER TABLE purchase_orders 
ADD CONSTRAINT purchase_orders_approval_status_check 
CHECK (approval_status IN ('pending', 'approved', 'rejected', 'cancelled'));