/*
  # Fix Payment Obligations Schema

  1. Changes
    - Add missing document_type, document_date, and document_number columns
    - Update constraints and indexes
    
  2. Security
    - Maintains existing RLS policies
*/

-- Add missing document-related columns
ALTER TABLE payment_obligations
ADD COLUMN IF NOT EXISTS document_type text CHECK (document_type IN ('factura', 'boleta', 'otro')),
ADD COLUMN IF NOT EXISTS document_date date,
ADD COLUMN IF NOT EXISTS document_number text;

-- Make the columns NOT NULL
DO $$
BEGIN
  -- First ensure the columns exist
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'payment_obligations' 
    AND column_name = 'document_type'
  ) THEN
    ALTER TABLE payment_obligations 
    ALTER COLUMN document_type SET NOT NULL;
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'payment_obligations' 
    AND column_name = 'document_date'
  ) THEN
    ALTER TABLE payment_obligations 
    ALTER COLUMN document_date SET NOT NULL;
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'payment_obligations' 
    AND column_name = 'document_number'
  ) THEN
    ALTER TABLE payment_obligations 
    ALTER COLUMN document_number SET NOT NULL;
  END IF;
END $$;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_payment_obligations_document_type 
ON payment_obligations(document_type);

CREATE INDEX IF NOT EXISTS idx_payment_obligations_document_date 
ON payment_obligations(document_date);