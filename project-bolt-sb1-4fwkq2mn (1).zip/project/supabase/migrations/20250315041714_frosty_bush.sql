/*
  # Store original values for purchase orders

  1. New Tables
    - `purchase_order_original_values`
      - Stores the original values of purchase orders before modification
      - Used to display original values until modifications are approved

  2. Changes
    - Add trigger to store original values when modifications are made
    - Add view to combine current and original values for display

  3. Security
    - Enable RLS on new table
    - Add policies for authenticated users
*/

-- Create table for original values
CREATE TABLE IF NOT EXISTS purchase_order_original_values (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  purchase_order_id uuid NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
  field_name text NOT NULL,
  original_value text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(purchase_order_id, field_name)
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_original_values_purchase_order 
ON purchase_order_original_values(purchase_order_id);

-- Enable RLS
ALTER TABLE purchase_order_original_values ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read original values"
  ON purchase_order_original_values
  FOR SELECT
  TO authenticated
  USING (true);

-- Create view for purchase orders with original/current values
CREATE OR REPLACE VIEW purchase_orders_with_values AS
WITH original_values AS (
  SELECT 
    purchase_order_id,
    jsonb_object_agg(field_name, original_value) as original_values
  FROM purchase_order_original_values
  GROUP BY purchase_order_id
)
SELECT 
  po.*,
  CASE 
    WHEN po.approval_status = 'pending' AND ov.original_values IS NOT NULL THEN
      COALESCE(ov.original_values->>'payment_type', po.payment_type)
    ELSE po.payment_type
  END as display_payment_type,
  CASE 
    WHEN po.approval_status = 'pending' AND ov.original_values IS NOT NULL THEN
      COALESCE(ov.original_values->>'currency', po.currency)
    ELSE po.currency
  END as display_currency,
  CASE 
    WHEN po.approval_status = 'pending' AND ov.original_values IS NOT NULL THEN
      COALESCE((ov.original_values->>'total')::numeric, po.total)
    ELSE po.total
  END as display_total
FROM purchase_orders po
LEFT JOIN original_values ov ON ov.purchase_order_id = po.id;

-- Grant access to the view
GRANT SELECT ON purchase_orders_with_values TO authenticated;

-- Create function to store original values
CREATE OR REPLACE FUNCTION store_original_values()
RETURNS trigger AS $$
BEGIN
  -- Store original values if they don't exist
  INSERT INTO purchase_order_original_values (
    purchase_order_id,
    field_name,
    original_value
  )
  SELECT
    NEW.id,
    unnest(array['payment_type', 'currency', 'total']),
    unnest(array[OLD.payment_type, OLD.currency, OLD.total::text])
  ON CONFLICT (purchase_order_id, field_name) DO NOTHING;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to store original values
CREATE TRIGGER store_original_values_trigger
BEFORE UPDATE ON purchase_orders
FOR EACH ROW
WHEN (NEW.approval_status = 'pending')
EXECUTE FUNCTION store_original_values();