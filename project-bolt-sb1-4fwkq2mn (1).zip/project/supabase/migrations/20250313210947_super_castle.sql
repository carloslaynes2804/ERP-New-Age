/*
  # Add Test User

  1. Changes
    - Creates a test user with email claynes.consultoria@gmail.com
    - Sets up initial bank and cash accounts for the user

  2. Security
    - Password is hashed using bcrypt
    - User is automatically confirmed
*/

-- Create test user
INSERT INTO auth.users (
  id,
  instance_id,
  email,
  encrypted_password,
  email_confirmed_at,
  raw_app_meta_data,
  raw_user_meta_data,
  created_at,
  updated_at,
  confirmation_token,
  email_change,
  email_change_token_new,
  recovery_token
) VALUES (
  gen_random_uuid(),
  '00000000-0000-0000-0000-000000000000',
  'claynes.consultoria@gmail.com',
  crypt('admin', gen_salt('bf')),
  now(),
  '{"provider":"email","providers":["email"]}',
  '{}',
  now(),
  now(),
  '',
  '',
  '',
  ''
);

-- Insert initial data for test user
DO $$
DECLARE
  v_user_id uuid;
BEGIN
  SELECT id INTO v_user_id FROM auth.users WHERE email = 'claynes.consultoria@gmail.com' LIMIT 1;

  -- Insert initial bank accounts
  INSERT INTO bank_accounts (name, number, user_id) VALUES
    ('BCP Soles', '193-2458789-0-24', v_user_id),
    ('BBVA Soles', '0011-0124-0100235489', v_user_id),
    ('Interbank Soles', '048-3012458789', v_user_id),
    ('BCP Dólares', '193-2557899-1-35', v_user_id);

  -- Insert initial cash accounts
  INSERT INTO cash_accounts (name, user_id) VALUES
    ('Caja 1', v_user_id),
    ('Caja 2', v_user_id),
    ('Caja 3', v_user_id);
END $$;