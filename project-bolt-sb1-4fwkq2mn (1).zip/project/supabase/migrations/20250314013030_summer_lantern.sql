/*
  # Update product line constraint in suppliers

  1. Changes
    - Modify product_line column constraint to include 'Otros' option
*/

-- Update check constraint for product_line if it exists
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.check_constraints 
    WHERE constraint_name = 'suppliers_product_line_check'
  ) THEN
    ALTER TABLE suppliers DROP CONSTRAINT suppliers_product_line_check;
  END IF;

  ALTER TABLE suppliers 
  ADD CONSTRAINT suppliers_product_line_check 
  CHECK (product_line IN ('Merchandising', 'Textil', 'Imprenta', 'Otros'));
END $$;