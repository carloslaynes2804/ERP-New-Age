/*
  # Add approval workflow fields to purchase orders

  1. Changes
    - Add approval workflow fields to purchase orders table
    - Add indexes for better query performance
*/

-- Add approval workflow fields if they don't exist
DO $$ 
BEGIN
  -- Add approver_id if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'purchase_orders' 
    AND column_name = 'approver_id'
  ) THEN
    ALTER TABLE purchase_orders 
    ADD COLUMN approver_id uuid REFERENCES users(id);
  END IF;

  -- Add approval_status if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'purchase_orders' 
    AND column_name = 'approval_status'
  ) THEN
    ALTER TABLE purchase_orders 
    ADD COLUMN approval_status text CHECK (approval_status IN ('pending', 'approved', 'rejected'));
  END IF;
END $$;

-- Create index for approver_id if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'purchase_orders' 
    AND indexname = 'idx_purchase_orders_approver'
  ) THEN
    CREATE INDEX idx_purchase_orders_approver ON purchase_orders(approver_id);
  END IF;
END $$;