/*
  # Fix Payment Obligations Schema

  1. Changes
    - Add missing columns to payment_obligations table:
      - concept
      - obligation_type
      - has_detraction
      - exchange_rate
      - total_amount_pen
    - Update payment method constraint to include all methods
    - Add indexes for better performance

  2. Security
    - No changes to existing policies
*/

-- Add missing columns to payment_obligations table
ALTER TABLE payment_obligations
ADD COLUMN IF NOT EXISTS concept text,
ADD COLUMN IF NOT EXISTS obligation_type text CHECK (obligation_type IN ('compras', 'prestamos', 'otros')),
ADD COLUMN IF NOT EXISTS has_detraction boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS exchange_rate numeric,
ADD COLUMN IF NOT EXISTS total_amount_pen numeric DEFAULT 0;

-- Drop existing payment_method constraint if it exists
ALTER TABLE payment_obligations 
DROP CONSTRAINT IF EXISTS payment_obligations_payment_method_check;

-- Add updated payment method constraint
ALTER TABLE payment_obligations 
ADD CONSTRAINT payment_obligations_payment_method_check 
CHECK (payment_method IN ('bank_transfer', 'check', 'cash', 'bank_deposit', 'yape', 'plin'));

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_payment_obligations_concept ON payment_obligations(concept);
CREATE INDEX IF NOT EXISTS idx_payment_obligations_obligation_type ON payment_obligations(obligation_type);