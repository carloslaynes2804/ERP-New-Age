/*
  # Add account holder field to supplier bank accounts

  1. Changes
    - Add account_holder column to supplier_bank_accounts table
    
  2. Notes
    - The account_holder field is required for all bank accounts
*/

-- Add account_holder column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'supplier_bank_accounts' 
    AND column_name = 'account_holder'
  ) THEN
    ALTER TABLE supplier_bank_accounts 
    ADD COLUMN account_holder text NOT NULL;
  END IF;
END $$;