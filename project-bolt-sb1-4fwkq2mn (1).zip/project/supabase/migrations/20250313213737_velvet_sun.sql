/*
  # Add roles for admin user

  1. Changes
    - Add all roles (logistics, sales, finance, management) for claynes.consultoria@gmail.com
  
  2. Security
    - Uses existing RLS policies
    - Only affects specified user
*/

DO $$
DECLARE
  v_user_id uuid;
BEGIN
  -- Get the user ID
  SELECT id INTO v_user_id FROM auth.users 
  WHERE email = 'claynes.consultoria@gmail.com' 
  LIMIT 1;

  -- Only proceed if user exists
  IF v_user_id IS NOT NULL THEN
    -- Insert all roles for the user
    INSERT INTO user_roles (user_id, role)
    VALUES 
      (v_user_id, 'logistics'),
      (v_user_id, 'sales'),
      (v_user_id, 'finance'),
      (v_user_id, 'management')
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;
END $$;