/*
  # Update suppliers and add bank accounts

  1. Changes
    - Add new fields to suppliers table:
      - website
      - contact information (name, phone, email)
      - payment methods (main method, mobile payment number)
    - Create supplier_bank_accounts table with:
      - Bank account details (bank, account number, CCI)
      - Timestamps
      - Foreign key to suppliers
    
  2. Security
    - Enable RLS on new table
    - Add policy for authenticated users to manage bank accounts
*/

-- Add new columns to suppliers table if they don't exist
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'suppliers' AND column_name = 'website') THEN
    ALTER TABLE suppliers ADD COLUMN website text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'suppliers' AND column_name = 'contact_name') THEN
    ALTER TABLE suppliers ADD COLUMN contact_name text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'suppliers' AND column_name = 'contact_phone') THEN
    ALTER TABLE suppliers ADD COLUMN contact_phone text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'suppliers' AND column_name = 'contact_email') THEN
    ALTER TABLE suppliers ADD COLUMN contact_email text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'suppliers' AND column_name = 'main_payment_method') THEN
    ALTER TABLE suppliers ADD COLUMN main_payment_method text CHECK (main_payment_method IN ('bank_deposit', 'yape', 'plin', 'cash'));
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'suppliers' AND column_name = 'mobile_payment_number') THEN
    ALTER TABLE suppliers ADD COLUMN mobile_payment_number text;
  END IF;
END $$;

-- Create supplier_bank_accounts table if it doesn't exist
CREATE TABLE IF NOT EXISTS supplier_bank_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  supplier_id uuid NOT NULL REFERENCES suppliers(id) ON DELETE CASCADE,
  bank text NOT NULL CHECK (bank IN ('BCP', 'Interbank', 'BBVA', 'Scotiabank')),
  account_number text NOT NULL,
  cci_number text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create index only if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'supplier_bank_accounts' 
    AND indexname = 'idx_supplier_bank_accounts_supplier'
  ) THEN
    CREATE INDEX idx_supplier_bank_accounts_supplier ON supplier_bank_accounts(supplier_id);
  END IF;
END $$;

-- Enable RLS and create policy
ALTER TABLE supplier_bank_accounts ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'supplier_bank_accounts' 
    AND policyname = 'Users can manage supplier bank accounts'
  ) THEN
    CREATE POLICY "Users can manage supplier bank accounts"
      ON supplier_bank_accounts
      FOR ALL
      TO authenticated
      USING (true);
  END IF;
END $$;