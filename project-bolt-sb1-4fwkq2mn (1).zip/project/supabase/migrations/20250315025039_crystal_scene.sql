/*
  # Create Payment Obligations Schema

  1. New Tables
    - `payment_obligations`
      - Header information for payment obligations
      - References to purchase orders and suppliers
      - Payment details and status

  2. Security
    - Enable RLS on new table
    - Add policies for authenticated users
*/

-- Create payment_obligations table
CREATE TABLE IF NOT EXISTS payment_obligations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  number serial UNIQUE NOT NULL,
  date date NOT NULL DEFAULT CURRENT_DATE,
  purchase_order_id uuid NOT NULL REFERENCES purchase_orders(id),
  supplier_id uuid NOT NULL REFERENCES suppliers(id),
  created_by uuid NOT NULL REFERENCES users(id),
  payment_type text NOT NULL CHECK (payment_type IN ('cash', 'credit')),
  payment_method text NOT NULL CHECK (payment_method IN ('bank_transfer', 'check', 'cash')),
  bank text CHECK (bank IN ('BCP', 'Interbank', 'BBVA', 'Scotiabank')),
  currency text NOT NULL CHECK (currency IN ('PEN', 'USD')),
  total numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'paid', 'cancelled')),
  payment_date date,
  due_date date,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX idx_payment_obligations_number ON payment_obligations(number);
CREATE INDEX idx_payment_obligations_purchase_order ON payment_obligations(purchase_order_id);
CREATE INDEX idx_payment_obligations_supplier ON payment_obligations(supplier_id);
CREATE INDEX idx_payment_obligations_created_by ON payment_obligations(created_by);
CREATE INDEX idx_payment_obligations_date ON payment_obligations(date);
CREATE INDEX idx_payment_obligations_status ON payment_obligations(status);

-- Enable RLS
ALTER TABLE payment_obligations ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can manage payment obligations"
  ON payment_obligations
  FOR ALL
  TO authenticated
  USING (created_by = auth.uid());

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION update_payment_obligation_timestamps()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for timestamps
CREATE TRIGGER update_payment_obligation_timestamps_trigger
  BEFORE UPDATE ON payment_obligations
  FOR EACH ROW
  EXECUTE FUNCTION update_payment_obligation_timestamps();