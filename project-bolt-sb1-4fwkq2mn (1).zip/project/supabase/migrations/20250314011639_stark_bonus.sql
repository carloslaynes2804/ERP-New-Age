/*
  # Add users table and display name

  1. New Tables
    - `users` table with basic fields and display_name if it doesn't exist
  2. Security
    - Enable RLS on users table
    - Add policy for authenticated users to read their own data if it doesn't exist
*/

-- Create users table if it doesn't exist
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Create policy if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'users' 
    AND policyname = 'Users can read their own data'
  ) THEN
    CREATE POLICY "Users can read their own data"
      ON users
      FOR SELECT
      TO authenticated
      USING (auth.uid() = id);
  END IF;
END $$;

-- Insert example user if they don't exist
INSERT INTO users (id, display_name)
SELECT id, 'Carlos Laynes'
FROM auth.users
WHERE NOT EXISTS (
  SELECT 1 FROM users WHERE id = auth.users.id
)
LIMIT 1;