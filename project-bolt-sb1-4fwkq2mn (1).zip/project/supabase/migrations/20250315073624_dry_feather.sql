/*
  # Remove redundant payment date fields

  1. Changes
    - Remove payment_date and due_date columns from payment_obligations table
    - These dates are now handled in the payment_obligation_schedule table
    
  2. Security
    - Maintains existing RLS policies
*/

-- Remove redundant date columns
ALTER TABLE payment_obligations
DROP COLUMN IF EXISTS payment_date,
DROP COLUMN IF EXISTS due_date;