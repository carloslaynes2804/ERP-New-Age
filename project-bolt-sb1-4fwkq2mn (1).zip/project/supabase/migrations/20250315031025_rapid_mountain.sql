/*
  # Fix notifications table RLS policies

  1. Changes
    - Add INSERT policy for notifications table
    - Update existing SELECT policy to be more specific
    
  2. Security
    - Allow authenticated users to create notifications
    - Maintain read access for users' own notifications
*/

-- Drop existing policy if it exists
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'notifications' 
    AND policyname = 'Users can read their own notifications'
  ) THEN
    DROP POLICY "Users can read their own notifications" ON notifications;
  END IF;
END $$;

-- Create comprehensive policies for notifications
CREATE POLICY "Users can read their own notifications"
  ON notifications
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can create notifications"
  ON notifications
  FOR INSERT
  TO authenticated
  WITH CHECK (true);