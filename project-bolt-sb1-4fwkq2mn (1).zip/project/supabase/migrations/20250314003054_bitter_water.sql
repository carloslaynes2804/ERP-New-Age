/*
  # Create Purchase Orders Schema

  1. New Tables
    - `suppliers`
      - Basic supplier information
      - Contact details
      - Payment terms
    - `purchase_orders`
      - Header information for purchase orders
      - References to suppliers
      - Payment and delivery details
    - `purchase_order_items`
      - Line items for purchase orders
      - Product details and pricing

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create suppliers table
CREATE TABLE IF NOT EXISTS suppliers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  name text NOT NULL,
  tax_id text,
  address text,
  phone text,
  email text,
  payment_terms integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_suppliers_code ON suppliers(code);
CREATE INDEX idx_suppliers_name ON suppliers(name);

ALTER TABLE suppliers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read suppliers"
  ON suppliers
  FOR SELECT
  TO authenticated
  USING (true);

-- Create purchase_orders table
CREATE TABLE IF NOT EXISTS purchase_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  number serial UNIQUE NOT NULL,
  date date NOT NULL DEFAULT CURRENT_DATE,
  supplier_id uuid NOT NULL REFERENCES suppliers(id),
  payment_type text NOT NULL CHECK (payment_type IN ('cash', 'credit')),
  currency text NOT NULL CHECK (currency IN ('PEN', 'USD')),
  delivery_location text,
  observations text,
  order_reference text,
  status text NOT NULL DEFAULT 'generated' CHECK (status IN ('generated', 'approved', 'rejected', 'cancelled')),
  subtotal numeric NOT NULL DEFAULT 0,
  tax_rate numeric NOT NULL DEFAULT 0.18,
  tax_amount numeric NOT NULL DEFAULT 0,
  total numeric NOT NULL DEFAULT 0,
  created_by uuid NOT NULL REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_purchase_orders_number ON purchase_orders(number);
CREATE INDEX idx_purchase_orders_supplier ON purchase_orders(supplier_id);
CREATE INDEX idx_purchase_orders_date ON purchase_orders(date);
CREATE INDEX idx_purchase_orders_status ON purchase_orders(status);

ALTER TABLE purchase_orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage purchase orders"
  ON purchase_orders
  FOR ALL
  TO authenticated
  USING (created_by = auth.uid());

-- Create purchase_order_items table
CREATE TABLE IF NOT EXISTS purchase_order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  purchase_order_id uuid NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
  code text NOT NULL,
  description text NOT NULL,
  unit text NOT NULL,
  quantity numeric NOT NULL DEFAULT 0,
  unit_price numeric NOT NULL DEFAULT 0,
  discount_percent numeric NOT NULL DEFAULT 0,
  discount_amount numeric NOT NULL DEFAULT 0,
  subtotal numeric NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_purchase_order_items_po ON purchase_order_items(purchase_order_id);

ALTER TABLE purchase_order_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage purchase order items"
  ON purchase_order_items
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM purchase_orders
      WHERE id = purchase_order_items.purchase_order_id
      AND created_by = auth.uid()
    )
  );

-- Create function to update purchase order totals
CREATE OR REPLACE FUNCTION update_purchase_order_totals()
RETURNS TRIGGER AS $$
BEGIN
  -- Update the purchase order totals
  WITH totals AS (
    SELECT 
      purchase_order_id,
      SUM(subtotal) as subtotal
    FROM purchase_order_items
    WHERE purchase_order_id = NEW.purchase_order_id
    GROUP BY purchase_order_id
  )
  UPDATE purchase_orders
  SET 
    subtotal = totals.subtotal,
    tax_amount = totals.subtotal * tax_rate,
    total = totals.subtotal * (1 + tax_rate),
    updated_at = now()
  FROM totals
  WHERE purchase_orders.id = totals.purchase_order_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers to update totals
CREATE TRIGGER update_purchase_order_totals_trigger
  AFTER INSERT OR UPDATE OR DELETE ON purchase_order_items
  FOR EACH ROW
  EXECUTE FUNCTION update_purchase_order_totals();