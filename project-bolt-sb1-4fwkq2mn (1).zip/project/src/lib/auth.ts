import { User } from '@supabase/supabase-js';
import { supabase } from './supabase';

export type UserRole = 'logistics' | 'sales' | 'finance' | 'management';

export async function getUserRoles(user: User): Promise<UserRole[]> {
  if (!user) {
    throw new Error('No authenticated user');
  }

  try {
    const { data, error, status } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id);

    if (error) {
      if (status === 401) {
        // Handle unauthorized - likely need to refresh the session
        const { data: { session }, error: refreshError } = await supabase.auth.getSession();
        if (refreshError || !session) {
          throw new Error('Session expired');
        }
        
        // Retry the request with refreshed session
        const { data: retryData, error: retryError } = await supabase
          .from('user_roles')
          .select('role')
          .eq('user_id', user.id);
          
        if (retryError) throw retryError;
        return (retryData?.map(r => r.role as UserRole) || []);
      }
      throw error;
    }

    return (data?.map(r => r.role as UserRole) || []);
  } catch (error) {
    console.error('Error fetching user roles:', error);
    throw new Error('Error fetching user roles');
  }
}

export function hasAccess(roles: UserRole[], requiredRole: UserRole): boolean {
  return roles.includes('management') || roles.includes(requiredRole);
}

export const SECTION_ROLES = {
  'accounts-payable': ['logistics', 'management'] as UserRole[],
  'accounts-receivable': ['sales', 'management'] as UserRole[],
  'finance-control': ['finance', 'management'] as UserRole[],
};