import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { Eye, CheckCircle2, XCircle, AlertCircle, Clock, Calendar } from 'lucide-react';
import { getUserRoles } from '../../lib/auth';

interface ModifiedOrder {
  id: string;
  number: number;
  date: string;
  supplier: {
    name: string;
  };
  created_by_user: {
    display_name: string;
  };
  approver: {
    display_name: string;
  };
  payment_type: string;
  currency: string;
  total: number;
  display_payment_type: string;
  display_currency: string;
  display_total: number;
  status: string;
  approval_status: string;
  created_at: string;
}

interface ModificationHistory {
  id: string;
  created_at: string;
  field_name: string;
  old_value: string;
  new_value: string;
  modifier_name: string;
  modification_group: string;
}

interface GroupedModifications {
  id: string;
  date: string;
  time: string;
  modifier: string;
  changes: ModificationHistory[];
  sequence: number;
}

export function ModifiedOrdersList() {
  const [orders, setOrders] = useState<ModifiedOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [hasAccess, setHasAccess] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<ModifiedOrder | null>(null);
  const [showDetails, setShowDetails] = useState(false);
  const [modificationHistory, setModificationHistory] = useState<ModificationHistory[]>([]);
  const [groupedModifications, setGroupedModifications] = useState<GroupedModifications[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    checkAccess();
    loadOrders();
  }, []);

  const checkAccess = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const userRoles = await getUserRoles(user);
        setHasAccess(userRoles.includes('logistics'));
      }
    } catch (error) {
      console.error('Error checking access:', error);
    }
  };

  const loadOrders = async () => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('purchase_orders_with_values')
        .select(`
          id,
          number,
          date,
          supplier:suppliers(name),
          created_by_user:users!purchase_orders_created_by_fkey(display_name),
          approver:users!purchase_orders_approver_id_fkey(display_name),
          payment_type,
          currency,
          total,
          display_payment_type,
          display_currency,
          display_total,
          status,
          approval_status,
          created_at
        `)
        .not('approval_status', 'is', null)
        .neq('status', 'cancelled')
        .order('date', { ascending: false });

      if (error) throw error;
      setOrders(data || []);
    } catch (error) {
      console.error('Error loading orders:', error);
      setError('Error al cargar las órdenes modificadas');
    } finally {
      setLoading(false);
    }
  };

  const loadModificationHistory = async (orderId: string) => {
    try {
      setLoadingHistory(true);
      
      // First get the order creation details
      const { data: orderData, error: orderError } = await supabase
        .from('purchase_orders')
        .select(`
          created_at,
          created_by_user:users!purchase_orders_created_by_fkey(display_name)
        `)
        .eq('id', orderId)
        .single();

      if (orderError) throw orderError;

      // Then get modification history
      const { data: modData, error: modError } = await supabase
        .from('purchase_order_modifications_with_users')
        .select('*')
        .eq('purchase_order_id', orderId)
        .order('created_at', { ascending: true });

      if (modError) throw modError;
      
      const modifications = modData || [];

      // Group modifications by modification_group
      const grouped = modifications.reduce<{ [key: string]: ModificationHistory[] }>((acc, mod) => {
        const key = mod.modification_group;
        if (!acc[key]) {
          acc[key] = [];
        }
        acc[key].push(mod);
        return acc;
      }, {});

      // Convert to array and add sequence numbers
      const groupedArray = Object.entries(grouped).map(([key, changes]) => {
        const timestamp = new Date(changes[0].created_at);
        return {
          id: key,
          date: timestamp.toLocaleDateString(),
          time: timestamp.toLocaleTimeString(),
          modifier: changes[0].modifier_name,
          changes,
          sequence: 0
        };
      });

      // Sort by date and time, oldest first
      groupedArray.sort((a, b) => {
        const dateA = new Date(`${a.date} ${a.time}`);
        const dateB = new Date(`${b.date} ${b.time}`);
        return dateA.getTime() - dateB.getTime();
      });

      // Add sequence numbers after sorting
      const sequencedArray = groupedArray.map((group, index) => ({
        ...group,
        sequence: index + 1
      }));

      setGroupedModifications(sequencedArray);
    } catch (error) {
      console.error('Error loading modification history:', error);
      setError('Error al cargar el historial de modificaciones');
    } finally {
      setLoadingHistory(false);
    }
  };

  const handleViewDetails = async (order: ModifiedOrder) => {
    setSelectedOrder(order);
    setShowDetails(true);
    await loadModificationHistory(order.id);
  };

  const handleApprove = async (orderId: string) => {
    try {
      const { error: updateError } = await supabase
        .from('purchase_orders')
        .update({
          approval_status: 'approved',
          status: 'approved',
          updated_at: new Date().toISOString()
        })
        .eq('id', orderId);

      if (updateError) throw updateError;

      // Update notification status
      const { error: notificationError } = await supabase
        .from('notifications')
        .update({ status: 'actioned' })
        .eq('reference_id', orderId);

      if (notificationError) throw notificationError;

      // Delete original values
      const { error: deleteError } = await supabase
        .from('purchase_order_original_values')
        .delete()
        .eq('purchase_order_id', orderId);

      if (deleteError) throw deleteError;

      loadOrders();
      setShowDetails(false);
      setSelectedOrder(null);
    } catch (error) {
      console.error('Error approving order:', error);
      setError('Error al aprobar la orden');
    }
  };

  const handleReject = async (orderId: string) => {
    try {
      const { error: updateError } = await supabase
        .from('purchase_orders')
        .update({
          approval_status: 'rejected',
          status: 'rejected',
          updated_at: new Date().toISOString()
        })
        .eq('id', orderId);

      if (updateError) throw updateError;

      // Update notification status
      const { error: notificationError } = await supabase
        .from('notifications')
        .update({ status: 'actioned' })
        .eq('reference_id', orderId);

      if (notificationError) throw notificationError;

      loadOrders();
      setShowDetails(false);
      setSelectedOrder(null);
    } catch (error) {
      console.error('Error rejecting order:', error);
      setError('Error al rechazar la orden');
    }
  };

  const formatFieldName = (fieldName: string): string => {
    const fieldMappings: { [key: string]: string } = {
      payment_type: 'Tipo de pago',
      currency: 'Moneda',
      delivery_location: 'Lugar de entrega',
      observations: 'Observaciones',
      order_reference: 'Número de pedido',
      total: 'Total',
      'items.quantity': 'Cantidad',
      'items.unit_price': 'Precio unitario',
      'items.discount_percent': 'Porcentaje de descuento',
      'items.code': 'Código de producto',
      'items.description': 'Descripción de producto',
      'items.unit': 'Unidad de medida'
    };
    return fieldMappings[fieldName] || fieldName;
  };

  const formatValue = (fieldName: string, value: string): string => {
    if (fieldName === 'payment_type') {
      return value === 'cash' ? 'Contado' : 'Crédito';
    }
    if (fieldName === 'currency') {
      return value === 'PEN' ? 'Soles' : 'Dólares';
    }
    if (fieldName === 'total' || fieldName.includes('price') || fieldName.includes('amount')) {
      return parseFloat(value).toFixed(2);
    }
    return value || '-';
  };

  if (!hasAccess) {
    return (
      <div className="bg-white rounded-lg shadow p-6">
        <div className="text-center">
          <p className="text-gray-500">No tiene acceso a esta sección</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="px-4 py-4 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-800">Órdenes Modificadas</h2>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border-l-4 border-red-400">
          <div className="flex">
            <AlertCircle className="h-5 w-5 text-red-400" />
            <p className="ml-3 text-sm text-red-700">{error}</p>
          </div>
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                N° Orden
              </th>
              <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Fecha
              </th>
              <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Proveedor
              </th>
              <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Solicitante
              </th>
              <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Aprobador
              </th>
              <th className="px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Total
              </th>
              <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Estado de modificación
              </th>
              <th className="px-3 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                Acciones
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {loading ? (
              <tr>
                <td colSpan={8} className="px-3 py-4 text-center text-sm text-gray-500">
                  Cargando órdenes...
                </td>
              </tr>
            ) : orders.length === 0 ? (
              <tr>
                <td colSpan={8} className="px-3 py-4 text-center text-sm text-gray-500">
                  No hay órdenes modificadas pendientes de aprobación
                </td>
              </tr>
            ) : (
              orders.map((order) => (
                <tr key={order.id} className="hover:bg-gray-50">
                  <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-900">
                    {order.number.toString().padStart(6, '0')}
                  </td>
                  <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500">
                    {new Date(order.date).toLocaleDateString()}
                  </td>
                  <td className="px-3 py-2 text-sm text-gray-900 truncate max-w-[200px]">
                    {order.supplier.name}
                  </td>
                  <td className="px-3 py-2 text-sm text-gray-900 truncate max-w-[200px]">
                    {order.created_by_user.display_name}
                  </td>
                  <td className="px-3 py-2 text-sm text-gray-900 truncate max-w-[200px]">
                    {order.approver?.display_name || '-'}
                  </td>
                  <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-900 text-right">
                    {order.display_currency} {order.display_total.toFixed(2)}
                  </td>
                  <td className="px-3 py-2 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      order.approval_status === 'approved' ? 'bg-green-100 text-green-800' :
                      order.approval_status === 'rejected' ? 'bg-red-100 text-red-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {order.approval_status === 'pending' ? 'Pendiente' :
                       order.approval_status === 'approved' ? 'Aprobada' :
                       'Rechazada'}
                    </span>
                  </td>
                  <td className="px-3 py-2 whitespace-nowrap text-sm font-medium">
                    <div className="flex justify-center space-x-2">
                      {order.approval_status === 'pending' && (
                        <>
                          <button
                            onClick={() => handleApprove(order.id)}
                            className="text-green-600 hover:text-green-900 relative group"
                            title="Aprobar"
                          >
                            <CheckCircle2 className="h-5 w-5" />
                            <span className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 text-xs font-medium text-white bg-gray-900 rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap">
                              Aprobar
                            </span>
                          </button>
                          <button
                            onClick={() => handleReject(order.id)}
                            className="text-red-600 hover:text-red-900 relative group"
                            title="Rechazar"
                          >
                            <XCircle className="h-5 w-5" />
                            <span className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 text-xs font-medium text-white bg-gray-900 rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap">
                              Rechazar
                            </span>
                          </button>
                        </>
                      )}
                      <button
                        onClick={() => handleViewDetails(order)}
                        className="text-blue-600 hover:text-blue-900 relative group"
                        title="Ver detalles"
                      >
                        <Eye className="h-5 w-5" />
                        <span className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 text-xs font-medium text-white bg-gray-900 rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap">
                          Ver detalles
                        </span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {showDetails && selectedOrder && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h3 className="text-lg font-medium text-gray-900">
                  Historial de modificaciones - OC N° {selectedOrder.number.toString().padStart(6, '0')}
                </h3>
                <p className="mt-1 text-sm text-gray-500">
                  Proveedor: {selectedOrder.supplier.name}
                </p>
              </div>
              <button
                onClick={() => {
                  setShowDetails(false);
                  setSelectedOrder(null);
                  setModificationHistory([]);
                  setGroupedModifications([]);
                }}
                className="text-gray-400 hover:text-gray-500"
              >
                <XCircle className="h-5 w-5" />
              </button>
            </div>

            {loadingHistory ? (
              <div className="text-center py-4">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                <p className="mt-2 text-sm text-gray-500">Cargando historial...</p>
              </div>
            ) : (
              <div className="space-y-8">
                {/* Creation Event */}
                <div className="relative pb-8">
                  <div className="absolute left-4 -ml-px h-full w-0.5 bg-gray-200"></div>
                  <div className="relative flex items-start group">
                    <div className="flex h-8 items-center">
                      <div className="relative z-10 w-8 h-8 flex items-center justify-center bg-blue-100 rounded-full">
                        <Calendar className="h-5 w-5 text-blue-600" />
                      </div>
                    </div>
                    <div className="ml-4 min-w-0 flex-1">
                      <div className="text-sm font-medium text-gray-900">Creación de la orden</div>
                      <div className="mt-1 text-sm text-gray-500">
                        {new Date(selectedOrder.created_at).toLocaleString()}
                      </div>
                      <div className="mt-1 text-sm text-gray-500">
                        Por: {selectedOrder.created_by_user.display_name}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Modifications */}
                {groupedModifications.map((group) => (
                  <div key={group.id} className="relative pb-8">
                    <div className="absolute left-4 -ml-px h-full w-0.5 bg-gray-200"></div>
                    <div className="relative flex items-start group">
                      <div className="flex h-8 items-center">
                        <div className="relative z-10 w-8 h-8 flex items-center justify-center bg-blue-100 rounded-full">
                          <Clock className="h-5 w-5 text-blue-600" />
                        </div>
                      </div>
                      <div className="ml-4 min-w-0 flex-1">
                        <div className="text-sm font-medium text-gray-900">
                          Modificación {group.sequence}
                        </div>
                        <div className="mt-1 text-sm text-gray-500">
                          {group.date} - {group.time}
                        </div>
                        <div className="mt-1 text-sm text-gray-500">
                          Por: {group.modifier}
                        </div>
                        <div className="mt-2 bg-gray-50 rounded-lg p-4">
                          <table className="min-w-full">
                            <thead>
                              <tr>
                                <th className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider pb-3">
                                  Campo
                                </th>
                                <th className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider pb-3">
                                  Valor anterior
                                </th>
                                <th className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider pb-3">
                                  Nuevo valor
                                </th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                              {group.changes.map((change, index) => (
                                <tr key={change.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                                  <td className="py-2 text-sm font-medium text-gray-900">
                                    {formatFieldName(change.field_name)}
                                  </td>
                                  <td className="py-2 text-sm text-gray-700">
                                    {formatValue(change.field_name, change.old_value)}
                                  </td>
                                  <td className="py-2 text-sm text-gray-700">
                                    {formatValue(change.field_name, change.new_value)}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {selectedOrder.approval_status === 'pending' && (
              <div className="mt-6 border-t border-gray-200 pt-6 flex justify-end space-x-3">
                <button
                  onClick={() => {
                    handleReject(selectedOrder.id);
                  }}
                  className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                >
                  <XCircle className="h-4 w-4 mr-2 text-red-500" />
                  Rechazar modificaciones
                </button>
                <button
                  onClick={() => {
                    handleApprove(selectedOrder.id);
                  }}
                  className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                >
                  <CheckCircle2 className="h-4 w-4 mr-2" />
                  Aprobar modificaciones
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}