import React, { useState, useEffect } from 'react';
import { X, AlertCircle, CheckCircle2, Save } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface EditPurchaseOrderProps {
  orderId: string;
  onClose: () => void;
  onSave: () => void;
}

interface User {
  id: string;
  display_name: string;
}

interface PurchaseOrder {
  id: string;
  number: number;
  date: string;
  supplier_id: string;
  payment_type: string;
  currency: string;
  delivery_location: string | null;
  observations: string | null;
  order_reference: string | null;
  status: string;
  created_by: string;
  supplier: {
    name: string;
  };
  items: PurchaseOrderItem[];
}

interface PurchaseOrderItem {
  id: string;
  code: string;
  description: string;
  unit: string;
  quantity: number;
  unit_price: number;
  discount_percent: number;
  discount_amount: number;
  subtotal: number;
}

export function EditPurchaseOrder({ orderId, onClose, onSave }: EditPurchaseOrderProps) {
  const [order, setOrder] = useState<PurchaseOrder | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [managers, setManagers] = useState<User[]>([]);
  const [selectedManager, setSelectedManager] = useState<string>('');
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [formData, setFormData] = useState({
    payment_type: '',
    currency: '',
    delivery_location: '',
    observations: '',
    order_reference: ''
  });
  const [items, setItems] = useState<PurchaseOrderItem[]>([]);
  const [originalItems, setOriginalItems] = useState<PurchaseOrderItem[]>([]);

  useEffect(() => {
    loadOrder();
    loadManagers();
  }, [orderId]);

  const loadOrder = async () => {
    try {
      // Load order details
      const { data: orderData, error: orderError } = await supabase
        .from('purchase_orders')
        .select(`
          id,
          number,
          date,
          supplier_id,
          supplier:suppliers(name),
          payment_type,
          currency,
          delivery_location,
          observations,
          order_reference,
          status,
          created_by
        `)
        .eq('id', orderId)
        .single();

      if (orderError) throw orderError;

      // Load order items
      const { data: itemsData, error: itemsError } = await supabase
        .from('purchase_order_items')
        .select('*')
        .eq('purchase_order_id', orderId);

      if (itemsError) throw itemsError;

      setOrder({ ...orderData, items: itemsData || [] });
      setFormData({
        payment_type: orderData.payment_type,
        currency: orderData.currency,
        delivery_location: orderData.delivery_location || '',
        observations: orderData.observations || '',
        order_reference: orderData.order_reference || ''
      });
      setItems(itemsData || []);
      setOriginalItems([...itemsData] || []);
    } catch (error) {
      console.error('Error loading order:', error);
      setError('Error al cargar la orden de compra');
    } finally {
      setLoading(false);
    }
  };

  const loadManagers = async () => {
    try {
      const { data: rolesData, error: rolesError } = await supabase
        .from('user_roles')
        .select('user_id')
        .eq('role', 'logistics');

      if (rolesError) throw rolesError;

      const managerIds = rolesData.map(role => role.user_id);

      const { data: usersData, error: usersError } = await supabase
        .from('users')
        .select('id, display_name')
        .in('id', managerIds)
        .order('display_name');

      if (usersError) throw usersError;
      setManagers(usersData || []);
    } catch (error) {
      console.error('Error loading managers:', error);
      setError('Error al cargar los gerentes');
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const updateItem = (index: number, field: keyof PurchaseOrderItem, value: any) => {
    const newItems = [...items];
    newItems[index] = {
      ...newItems[index],
      [field]: value,
    };

    if (field === 'quantity' || field === 'unit_price' || field === 'discount_percent') {
      const quantity = parseFloat(newItems[index].quantity.toString());
      const unitPrice = parseFloat(newItems[index].unit_price.toString());
      const discountPercent = parseFloat(newItems[index].discount_percent.toString());
      
      const subtotalBeforeDiscount = quantity * unitPrice;
      const discountAmount = (subtotalBeforeDiscount * discountPercent) / 100;
      newItems[index].discount_amount = discountAmount;
      newItems[index].subtotal = subtotalBeforeDiscount - discountAmount;
    }

    setItems(newItems);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedManager) {
      setError('Por favor seleccione un gerente para aprobar los cambios');
      return;
    }

    setShowConfirmation(true);
  };

  const handleConfirmSave = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No authenticated user');

      // Generate a single modification group ID for all changes in this request
      const modificationGroup = crypto.randomUUID();

      // Update order details
      const { error: orderError } = await supabase
        .from('purchase_orders')
        .update({
          ...formData,
          approval_status: 'pending',
          approver_id: selectedManager,
          updated_at: new Date().toISOString()
        })
        .eq('id', orderId);

      if (orderError) throw orderError;

      // Track changes in order details
      const orderFields: (keyof typeof formData)[] = ['payment_type', 'currency', 'delivery_location', 'observations', 'order_reference'];
      
      for (const field of orderFields) {
        if (formData[field] !== order?.[field]) {
          const { error: modificationError } = await supabase
            .from('purchase_order_modifications')
            .insert({
              purchase_order_id: orderId,
              modified_by: user.id,
              field_name: field,
              old_value: (order?.[field] || '').toString(),
              new_value: formData[field].toString(),
              modification_group: modificationGroup
            });

          if (modificationError) throw modificationError;
        }
      }

      // Update order items and track changes
      for (let i = 0; i < items.length; i++) {
        const item = items[i];
        const originalItem = originalItems[i];

        // Update the item
        const { error: itemError } = await supabase
          .from('purchase_order_items')
          .update({
            code: item.code,
            description: item.description,
            unit: item.unit,
            quantity: item.quantity,
            unit_price: item.unit_price,
            discount_percent: item.discount_percent,
            discount_amount: item.discount_amount,
            subtotal: item.subtotal
          })
          .eq('id', item.id);

        if (itemError) throw itemError;

        // Track changes for each modified field
        const fields: (keyof PurchaseOrderItem)[] = ['code', 'description', 'unit', 'quantity', 'unit_price', 'discount_percent'];
        
        for (const field of fields) {
          if (item[field] !== originalItem[field]) {
            const { error: modificationError } = await supabase
              .from('purchase_order_modifications')
              .insert({
                purchase_order_id: orderId,
                modified_by: user.id,
                field_name: `items.${field}`,
                old_value: originalItem[field].toString(),
                new_value: item[field].toString(),
                modification_group: modificationGroup
              });

            if (modificationError) throw modificationError;
          }
        }
      }

      // Create notification for manager
      const { error: notificationError } = await supabase
        .from('notifications')
        .insert([{
          user_id: selectedManager,
          type: 'purchase_order_approval',
          content: `Solicitud de aprobación para modificación de OC ${order?.number}`,
          reference_id: orderId,
          status: 'pending'
        }]);

      if (notificationError) throw notificationError;

      onSave();
    } catch (error) {
      console.error('Error saving changes:', error);
      setError('Error al guardar los cambios');
    }
  };

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow p-6">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
        <p className="mt-2 text-center text-sm text-gray-500">Cargando orden...</p>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="bg-white rounded-lg shadow p-6">
        <div className="text-center">
          <AlertCircle className="h-8 w-8 text-red-500 mx-auto" />
          <p className="mt-2 text-red-600">No se encontró la orden de compra</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow">
      {/* Header */}
      <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
        <h2 className="text-xl font-semibold text-gray-800">
          Modificar Orden de Compra N° {order.number.toString().padStart(6, '0')}
        </h2>
        <button
          onClick={onClose}
          className="text-gray-400 hover:text-gray-500"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="p-6">
        {error && (
          <div className="mb-6 p-4 bg-red-50 border-l-4 border-red-400">
            <div className="flex">
              <AlertCircle className="h-5 w-5 text-red-400" />
              <p className="ml-3 text-sm text-red-700">{error}</p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-6 mb-6">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Proveedor
            </label>
            <input
              type="text"
              value={order.supplier.name}
              disabled
              className="mt-1 block w-full rounded-md border-gray-300 bg-gray-50 shadow-sm"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Gerente para aprobación
            </label>
            <select
              value={selectedManager}
              onChange={(e) => setSelectedManager(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="">Seleccione un gerente</option>
              {managers.map(manager => (
                <option key={manager.id} value={manager.id}>
                  {manager.display_name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Tipo de Pago
            </label>
            <select
              name="payment_type"
              value={formData.payment_type}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="cash">Contado</option>
              <option value="credit">Crédito</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Moneda
            </label>
            <select
              name="currency"
              value={formData.currency}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="PEN">Soles (PEN)</option>
              <option value="USD">Dólares (USD)</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Lugar de Entrega
            </label>
            <input
              type="text"
              name="delivery_location"
              value={formData.delivery_location}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Número de pedido
            </label>
            <input
              type="text"
              name="order_reference"
              value={formData.order_reference}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>

          <div className="col-span-2">
            <label className="block text-sm font-medium text-gray-700">
              Observaciones
            </label>
            <textarea
              name="observations"
              value={formData.observations}
              onChange={handleChange}
              rows={3}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Items */}
        <div className="mt-8">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Ítems</h3>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead>
                <tr>
                  <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Código</th>
                  <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Descripción</th>
                  <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Unidad</th>
                  <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cantidad</th>
                  <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Precio Unit.</th>
                  <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Desc. %</th>
                  <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Desc. Monto</th>
                  <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subtotal</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {items.map((item, index) => (
                  <tr key={item.id}>
                    <td className="px-3 py-4 whitespace-nowrap">
                      <input
                        type="text"
                        value={item.code}
                        onChange={(e) => updateItem(index, 'code', e.target.value)}
                        className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                      />
                    </td>
                    <td className="px-3 py-4 whitespace-nowrap">
                      <input
                        type="text"
                        value={item.description}
                        onChange={(e) => updateItem(index, 'description', e.target.value)}
                        className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                      />
                    </td>
                    <td className="px-3 py-4 whitespace-nowrap">
                      <input
                        type="text"
                        value={item.unit}
                        onChange={(e) => updateItem(index, 'unit', e.target.value)}
                        className="block w-40 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                      />
                    </td>
                    <td className="px-3 py-4 whitespace-nowrap">
                      <input
                        type="number"
                        value={item.quantity}
                        onChange={(e) => updateItem(index, 'quantity', parseFloat(e.target.value))}
                        className="block w-24 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                      />
                    </td>
                    <td className="px-3 py-4 whitespace-nowrap">
                      <input
                        type="number"
                        value={item.unit_price}
                        onChange={(e) => updateItem(index, 'unit_price', parseFloat(e.target.value))}
                        className="block w-32 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                      />
                    </td>
                    <td className="px-3 py-4 whitespace-nowrap">
                      <input
                        type="number"
                        value={item.discount_percent}
                        onChange={(e) => updateItem(index, 'discount_percent', parseFloat(e.target.value))}
                        className="block w-24 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                      />
                    </td>
                    <td className="px-3 py-4 whitespace-nowrap">
                      <input
                        type="number"
                        value={item.discount_amount}
                        disabled
                        className="block w-32 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm bg-gray-50"
                      />
                    </td>
                    <td className="px-3 py-4 whitespace-nowrap">
                      <input
                        type="number"
                        value={item.subtotal}
                        disabled
                        className="block w-32 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm bg-gray-50"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-8 flex justify-end space-x-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            Cancelar
          </button>
          <button
            type="submit"
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <Save className="h-4 w-4 mr-2" />
            Guardar Cambios
          </button>
        </div>
      </form>

      {/* Confirmation Modal */}
      {showConfirmation && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-sm w-full">
            <div className="flex items-center mb-4">
              <CheckCircle2 className="h-6 w-6 text-green-500 mr-2" />
              <h3 className="text-lg font-medium">Confirmar Modificación</h3>
            </div>
            <p className="text-gray-500 mb-4">
              Esta modificación requiere aprobación. Se enviará una notificación al gerente seleccionado para su revisión.
            </p>
            <div className="flex justify-end space-x-3">
              <button
                type="button"
                onClick={() => setShowConfirmation(false)}
                className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleConfirmSave}
                className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
              >
                Confirmar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}