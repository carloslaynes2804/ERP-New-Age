import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';

interface PaymentObligation {
  id: string;
  number: number;
  purchase_order: {
    number: number;
  };
  supplier: {
    name: string;
  };
  user: {
    display_name: string;
  };
  payment_type: string;
  payment_method: string;
  bank: string;
  currency: string;
  total: number;
  status: string;
}

interface User {
  id: string;
  display_name: string;
}

export function PaymentObligationsList() {
  const [obligations, setObligations] = useState<PaymentObligation[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    month: new Date().getMonth() + 1,
    year: new Date().getFullYear(),
    responsible: '',
    paymentMethod: '',
    status: ''
  });

  useEffect(() => {
    loadObligations();
    loadUsers();
  }, [filters]);

  const loadUsers = async () => {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('id, display_name')
        .order('display_name');

      if (error) throw error;
      setUsers(data || []);
    } catch (error) {
      console.error('Error loading users:', error);
    }
  };

  const loadObligations = async () => {
    try {
      setLoading(true);
      
      let query = supabase
        .from('payment_obligations')
        .select(`
          id,
          number,
          purchase_order:purchase_orders(number),
          supplier:suppliers(name),
          user:users(display_name),
          payment_type,
          payment_method,
          bank,
          currency,
          total,
          status
        `)
        .order('date', { ascending: false });

      // Apply filters
      if (filters.month && filters.year) {
        const startDate = `${filters.year}-${String(filters.month).padStart(2, '0')}-01`;
        const endDate = `${filters.year}-${String(filters.month).padStart(2, '0')}-31`;
        query = query.gte('date', startDate).lte('date', endDate);
      }

      if (filters.responsible) {
        query = query.eq('created_by', filters.responsible);
      }

      if (filters.paymentMethod) {
        query = query.eq('payment_method', filters.paymentMethod);
      }

      if (filters.status) {
        query = query.eq('status', filters.status);
      }

      const { data, error } = await query;

      if (error) throw error;
      setObligations(data || []);
    } catch (error) {
      console.error('Error loading obligations:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (name: string, value: string | number) => {
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <div className="bg-white rounded-lg shadow">
      {/* Header */}
      <div className="px-4 py-4 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-800">Obligaciones por pagar</h2>
        </div>
      </div>

      {/* Filters */}
      <div className="px-4 py-3 border-b border-gray-200 bg-gray-50">
        <div className="grid grid-cols-5 gap-3">
          <div>
            <label className="block text-sm font-medium text-gray-700">Mes</label>
            <select
              value={filters.month}
              onChange={(e) => handleFilterChange('month', parseInt(e.target.value))}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm"
            >
              {Array.from({ length: 12 }, (_, i) => i + 1).map(month => (
                <option key={month} value={month}>
                  {new Date(2000, month - 1).toLocaleString('default', { month: 'long' })}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Año</label>
            <select
              value={filters.year}
              onChange={(e) => handleFilterChange('year', parseInt(e.target.value))}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm"
            >
              {Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i).map(year => (
                <option key={year} value={year}>{year}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Solicitante Logística</label>
            <select
              value={filters.responsible}
              onChange={(e) => handleFilterChange('responsible', e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm"
            >
              <option value="">Todos</option>
              {users.map(user => (
                <option key={user.id} value={user.id}>
                  {user.display_name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Medio de pago</label>
            <select
              value={filters.paymentMethod}
              onChange={(e) => handleFilterChange('paymentMethod', e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm"
            >
              <option value="">Todos</option>
              <option value="bank_transfer">Transferencia</option>
              <option value="check">Cheque</option>
              <option value="cash">Efectivo</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Estado</label>
            <select
              value={filters.status}
              onChange={(e) => handleFilterChange('status', e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm"
            >
              <option value="">Todos</option>
              <option value="pending">Pendiente</option>
              <option value="approved">Aprobado</option>
              <option value="paid">Pagado</option>
              <option value="cancelled">Anulado</option>
            </select>
          </div>
        </div>
      </div>

      {/* Obligations List */}
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-24">
                N° Orden Pago
              </th>
              <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-24">
                N° OC
              </th>
              <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Proveedor
              </th>
              <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Solicitante Logística
              </th>
              <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-28">
                Tipo Pago
              </th>
              <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-28">
                Medio Pago
              </th>
              <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-28">
                Banco
              </th>
              <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-20">
                Moneda
              </th>
              <th className="px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider w-28">
                Total
              </th>
              <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-28">
                Estado
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {loading ? (
              <tr>
                <td colSpan={10} className="px-3 py-4 text-center text-sm text-gray-500">
                  Cargando obligaciones...
                </td>
              </tr>
            ) : obligations.length === 0 ? (
              <tr>
                <td colSpan={10} className="px-3 py-4 text-center text-sm text-gray-500">
                  No se encontraron obligaciones de pago
                </td>
              </tr>
            ) : (
              obligations.map((obligation) => (
                <tr key={obligation.id} className="hover:bg-gray-50">
                  <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-900">
                    {obligation.number.toString().padStart(6, '0')}
                  </td>
                  <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-900">
                    {obligation.purchase_order.number.toString().padStart(6, '0')}
                  </td>
                  <td className="px-3 py-2 text-sm text-gray-900 truncate max-w-[200px]">
                    {obligation.supplier.name}
                  </td>
                  <td className="px-3 py-2 text-sm text-gray-900 truncate max-w-[200px]">
                    {obligation.user.display_name}
                  </td>
                  <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500">
                    {obligation.payment_type === 'cash' ? 'Contado' : 'Crédito'}
                  </td>
                  <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500">
                    {obligation.payment_method === 'bank_transfer' ? 'Transferencia' :
                     obligation.payment_method === 'check' ? 'Cheque' : 'Efectivo'}
                  </td>
                  <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500">
                    {obligation.bank || '-'}
                  </td>
                  <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500">
                    {obligation.currency}
                  </td>
                  <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-900 text-right">
                    {obligation.total.toFixed(2)}
                  </td>
                  <td className="px-3 py-2 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      obligation.status === 'approved' ? 'bg-green-100 text-green-800' :
                      obligation.status === 'paid' ? 'bg-blue-100 text-blue-800' :
                      obligation.status === 'cancelled' ? 'bg-gray-100 text-gray-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {obligation.status === 'pending' ? 'Pendiente' :
                       obligation.status === 'approved' ? 'Aprobado' :
                       obligation.status === 'paid' ? 'Pagado' :
                       'Anulado'}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}