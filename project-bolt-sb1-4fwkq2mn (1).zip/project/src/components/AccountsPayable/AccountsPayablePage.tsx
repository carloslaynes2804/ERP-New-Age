import React, { useState } from 'react';
import { FileText, CreditCard, ClipboardEdit, Home } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import NewPurchaseOrder from './NewPurchaseOrder';
import { PurchaseOrdersList } from './PurchaseOrdersList';
import { PaymentObligationsList } from './PaymentObligationsList';
import { ModifiedOrdersList } from './ModifiedOrdersList';
import { EditPurchaseOrder } from './EditPurchaseOrder';

export function AccountsPayablePage() {
  const navigate = useNavigate();
  const location = useLocation();
  const [activeSection, setActiveSection] = useState(location.pathname.split('/')[2] || '');
  const [showNewPurchaseOrder, setShowNewPurchaseOrder] = useState(false);
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const [refreshOrders, setRefreshOrders] = useState(0);

  const handleNavigation = (path: string) => {
    setActiveSection(path);
    navigate(`/accounts-payable/${path}`);
  };

  const handleOrderCreated = () => {
    setRefreshOrders(prev => prev + 1);
  };

  const handleEditOrder = (orderId: string) => {
    setSelectedOrderId(orderId);
  };

  const handleEditComplete = () => {
    setSelectedOrderId(null);
    setRefreshOrders(prev => prev + 1);
  };

  const renderContent = () => {
    if (showNewPurchaseOrder) {
      return (
        <NewPurchaseOrder 
          onClose={() => setShowNewPurchaseOrder(false)} 
          onOrderCreated={handleOrderCreated}
        />
      );
    }

    if (selectedOrderId) {
      return (
        <EditPurchaseOrder
          orderId={selectedOrderId}
          onClose={() => setSelectedOrderId(null)}
          onSave={handleEditComplete}
        />
      );
    }

    switch (activeSection) {
      case 'purchase-orders':
        return (
          <PurchaseOrdersList 
            onNewOrder={() => setShowNewPurchaseOrder(true)}
            onEditOrder={handleEditOrder}
            refreshTrigger={refreshOrders}
          />
        );
      case 'payment-obligations':
        return <PaymentObligationsList />;
      case 'modified-orders':
        return <ModifiedOrdersList />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Navigation Bar */}
      <div className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <h1 className="text-xl font-semibold text-gray-900">Cuentas por Pagar</h1>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/')}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-gray-700 bg-gray-100 hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
              >
                <Home className="h-4 w-4 mr-2" />
                Volver al menú principal
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="flex">
        {/* Left Sidebar */}
        <div className="w-64 bg-white shadow-md min-h-[calc(100vh-4rem)]">
          <div className="p-4">
            <p className="text-sm text-gray-500">Gestión de pagos a proveedores</p>
          </div>
          <nav className="mt-4">
            <button
              onClick={() => handleNavigation('purchase-orders')}
              className={`w-full flex items-center px-4 py-3 text-sm font-medium ${
                activeSection === 'purchase-orders'
                  ? 'bg-blue-50 text-blue-700 border-l-4 border-blue-700'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <FileText className="h-5 w-5 mr-3" />
              Órdenes de Compra
            </button>

            <button
              onClick={() => handleNavigation('modified-orders')}
              className={`w-full flex items-center px-4 py-3 text-sm font-medium ${
                activeSection === 'modified-orders'
                  ? 'bg-blue-50 text-blue-700 border-l-4 border-blue-700'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <ClipboardEdit className="h-5 w-5 mr-3" />
              Órdenes modificadas
            </button>

            <button
              onClick={() => handleNavigation('payment-obligations')}
              className={`w-full flex items-center px-4 py-3 text-sm font-medium ${
                activeSection === 'payment-obligations'
                  ? 'bg-blue-50 text-blue-700 border-l-4 border-blue-700'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <CreditCard className="h-5 w-5 mr-3" />
              Obligaciones por pagar
            </button>
          </nav>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 overflow-auto">
          <div className="py-6 px-8">
            {renderContent()}
          </div>
        </div>
      </div>
    </div>
  );
}