import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { getSunatExchangeRate } from '../../lib/sunat';
import { X, AlertCircle, Save, Edit } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { SupplierForm } from './SupplierForm';

interface PaymentOrderFormProps {
  purchaseOrder: {
    id: string;
    number: string;
    supplier: {
      id: string;
      name: string;
    };
    currency: string;
    total: number;
  };
  onClose: () => void;
  onSave: () => void;
}

interface PaymentScheduleItem {
  payment_number: number;
  percentage: number;
  amount_pen: number;
  payment_date: string;
}

interface BankAccount {
  id: string;
  bank: string;
  account_number: string;
  cci_number: string;
  account_holder: string;
}

interface Supplier {
  id: string;
  name: string;
  code: string;
  tax_id: string;
  address: string;
  phone: string;
  email: string;
  website: string;
  contact_name: string;
  contact_phone: string;
  contact_email: string;
  mobile_payment_number?: string;
  main_payment_method?: string;
  product_line: string;
}

export function PaymentOrderForm({ purchaseOrder, onClose, onSave }: PaymentOrderFormProps) {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [nextNumber, setNextNumber] = useState<number | null>(null);
  const [exchangeRate, setExchangeRate] = useState<number>(1);
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>([]);
  const [selectedBankAccount, setSelectedBankAccount] = useState<BankAccount | null>(null);
  const [supplierDetails, setSupplierDetails] = useState<Supplier | null>(null);
  const [showEditSupplierForm, setShowEditSupplierForm] = useState(false);
  const [formData, setFormData] = useState({
    document_type: 'factura',
    document_date: new Date().toISOString().split('T')[0],
    document_number: '',
    concept: '',
    observations: '',
    obligation_type: 'compras',
    has_detraction: false,
    currency: purchaseOrder.currency,
    original_amount: purchaseOrder.total,
    payment_type: 'cash',
    payment_method: 'bank_deposit',
    bank: '',
    payment_date: new Date().toISOString().split('T')[0],
    due_date: new Date().toISOString().split('T')[0]
  });

  const [paymentSchedule, setPaymentSchedule] = useState<PaymentScheduleItem[]>([
    {
      payment_number: 1,
      percentage: 100,
      amount_pen: purchaseOrder.total * (purchaseOrder.currency === 'USD' ? exchangeRate : 1),
      payment_date: new Date().toISOString().split('T')[0]
    }
  ]);

  useEffect(() => {
    getNextPaymentNumber();
    loadSupplierDetails();
    if (purchaseOrder.currency === 'USD') {
      loadExchangeRate();
    }
  }, []);

  const loadExchangeRate = async () => {
    try {
      const rate = await getSunatExchangeRate();
      setExchangeRate(rate);
      
      setPaymentSchedule(prev => prev.map(item => ({
        ...item,
        amount_pen: (purchaseOrder.total * rate * item.percentage) / 100
      })));
    } catch (error) {
      console.error('Error loading exchange rate:', error);
      setError('Error al obtener el tipo de cambio de SUNAT');
    }
  };

  const loadSupplierDetails = async () => {
    try {
      const { data: supplierData, error: supplierError } = await supabase
        .from('suppliers')
        .select('*')
        .eq('id', purchaseOrder.supplier.id)
        .single();

      if (supplierError) throw supplierError;
      setSupplierDetails(supplierData);

      const { data: accountsData, error: accountsError } = await supabase
        .from('supplier_bank_accounts')
        .select('*')
        .eq('supplier_id', purchaseOrder.supplier.id)
        .order('created_at');

      if (accountsError) throw accountsError;
      setBankAccounts(accountsData || []);

      if (accountsData && accountsData.length > 0) {
        setSelectedBankAccount(accountsData[0]);
        setFormData(prev => ({
          ...prev,
          bank: accountsData[0].bank,
          payment_method: supplierData.main_payment_method || 'bank_deposit'
        }));
      }
    } catch (error) {
      console.error('Error loading supplier details:', error);
      setError('Error al cargar los datos del proveedor');
    }
  };

  const getNextPaymentNumber = async () => {
    try {
      const { data, error } = await supabase
        .from('payment_obligations')
        .select('number')
        .order('number', { ascending: false })
        .limit(1);

      if (error) throw error;
      setNextNumber((data?.[0]?.number || 0) + 1);
    } catch (error) {
      console.error('Error getting next payment number:', error);
      setError('Error al obtener el número de orden de pago');
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    
    if (name === 'bank') {
      const account = bankAccounts.find(acc => acc.bank === value);
      setSelectedBankAccount(account || null);
    }

    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    }));
  };

  const handleEditSupplier = () => {
    setShowEditSupplierForm(true);
  };

  const handleSupplierSaved = async () => {
    setShowEditSupplierForm(false);
    await loadSupplierDetails();
  };

  const updatePaymentSchedule = (index: number, field: keyof PaymentScheduleItem, value: any) => {
    const newSchedule = [...paymentSchedule];
    newSchedule[index] = {
      ...newSchedule[index],
      [field]: value
    };

    if (field === 'percentage') {
      const totalAmount = formData.original_amount * (formData.currency === 'USD' ? exchangeRate : 1);
      newSchedule[index].amount_pen = (totalAmount * parseFloat(value)) / 100;
    }

    setPaymentSchedule(newSchedule);
  };

  const addPaymentScheduleItem = () => {
    if (paymentSchedule.length >= 4) return;

    setPaymentSchedule(prev => [
      ...prev,
      {
        payment_number: prev.length + 1,
        percentage: 0,
        amount_pen: 0,
        payment_date: new Date().toISOString().split('T')[0]
      }
    ]);
  };

  const validateSchedule = (): boolean => {
    const totalPercentage = paymentSchedule.reduce((sum, item) => sum + item.percentage, 0);
    if (Math.abs(totalPercentage - 100) > 0.01) {
      setError('La suma de los porcentajes debe ser 100%');
      return false;
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateSchedule()) return;

    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No authenticated user');

      const totalAmountPen = formData.original_amount * (formData.currency === 'USD' ? exchangeRate : 1);

      const { data: obligationData, error: obligationError } = await supabase
        .from('payment_obligations')
        .insert([{
          purchase_order_id: purchaseOrder.id,
          supplier_id: purchaseOrder.supplier.id,
          ...formData,
          exchange_rate: formData.currency === 'USD' ? exchangeRate : null,
          total_amount_pen: totalAmountPen,
          created_by: user.id,
          status: 'pending'
        }])
        .select()
        .single();

      if (obligationError) throw obligationError;

      const { error: scheduleError } = await supabase
        .from('payment_obligation_schedule')
        .insert(
          paymentSchedule.map(item => ({
            payment_obligation_id: obligationData.id,
            ...item
          }))
        );

      if (scheduleError) throw scheduleError;

      onSave();
    } catch (error) {
      console.error('Error creating payment obligation:', error);
      setError('Error al crear la orden de pago');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold text-gray-800">
            Nueva Orden de Pago
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border-l-4 border-red-400">
            <div className="flex">
              <AlertCircle className="h-5 w-5 text-red-400" />
              <p className="ml-3 text-sm text-red-700">{error}</p>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                N° Orden de Pago
              </label>
              <input
                type="text"
                value={nextNumber?.toString().padStart(6, '0') || ''}
                disabled
                className="mt-1 block w-full rounded-md border-gray-300 bg-gray-50 shadow-sm"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Proveedor
              </label>
              <input
                type="text"
                value={purchaseOrder.supplier.name}
                disabled
                className="mt-1 block w-full rounded-md border-gray-300 bg-gray-50 shadow-sm"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                N° Orden de Compra
              </label>
              <input
                type="text"
                value={purchaseOrder.number}
                disabled
                className="mt-1 block w-full rounded-md border-gray-300 bg-gray-50 shadow-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Documento
              </label>
              <select
                name="document_type"
                value={formData.document_type}
                onChange={handleChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="factura">Factura</option>
                <option value="boleta">Boleta</option>
                <option value="otro">Otro documento</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Fecha de documento
              </label>
              <input
                type="date"
                name="document_date"
                value={formData.document_date}
                onChange={handleChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Número de documento
              </label>
              <input
                type="text"
                name="document_number"
                value={formData.document_number}
                onChange={handleChange}
                required
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Concepto
              </label>
              <input
                type="text"
                name="concept"
                value={formData.concept}
                onChange={handleChange}
                required
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Obligación
              </label>
              <select
                name="obligation_type"
                value={formData.obligation_type}
                onChange={handleChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="compras">Compras</option>
                <option value="prestamos">Préstamos</option>
                <option value="otros">Otros</option>
              </select>
            </div>

            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700">
                Observación
              </label>
              <textarea
                name="observations"
                value={formData.observations}
                onChange={handleChange}
                rows={2}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="flex items-center text-sm font-medium text-gray-700">
                <input
                  type="checkbox"
                  name="has_detraction"
                  checked={formData.has_detraction}
                  onChange={handleChange}
                  className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
                <span className="ml-2">Afecto a detracción</span>
              </label>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Moneda
              </label>
              <input
                type="text"
                value={formData.currency === 'PEN' ? 'Soles' : 'Dólares'}
                disabled
                className="mt-1 block w-full rounded-md border-gray-300 bg-gray-50 shadow-sm"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Importe total moneda original
              </label>
              <input
                type="number"
                value={formData.original_amount}
                disabled
                className="mt-1 block w-full rounded-md border-gray-300 bg-gray-50 shadow-sm"
              />
            </div>

            {formData.currency === 'USD' && (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Tipo de cambio SUNAT
                  </label>
                  <input
                    type="number"
                    value={exchangeRate}
                    disabled
                    className="mt-1 block w-full rounded-md border-gray-300 bg-gray-50 shadow-sm"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Importe total en soles
                  </label>
                  <input
                    type="number"
                    value={(formData.original_amount * exchangeRate).toFixed(2)}
                    disabled
                    className="mt-1 block w-full rounded-md border-gray-300 bg-gray-50 shadow-sm"
                  />
                </div>
              </>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Forma de pago
              </label>
              <select
                name="payment_type"
                value={formData.payment_type}
                onChange={handleChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="cash">Contado</option>
                <option value="credit">Crédito</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Método de pago
              </label>
              <select
                name="payment_method"
                value={formData.payment_method}
                onChange={handleChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="bank_deposit">Depósito bancario</option>
                <option value="check">Cheque</option>
                <option value="cash">Efectivo</option>
                <option value="yape">Yape</option>
                <option value="plin">Plin</option>
              </select>
            </div>

            {(formData.payment_method === 'yape' || formData.payment_method === 'plin') && (
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Número de {formData.payment_method === 'yape' ? 'Yape' : 'Plin'}
                </label>
                <div className="mt-1 flex items-center space-x-2">
                  <input
                    type="text"
                    value={supplierDetails?.mobile_payment_number || ''}
                    disabled
                    className="block w-full rounded-md border-gray-300 bg-gray-50 shadow-sm"
                    placeholder="No hay número registrado"
                  />
                  <button
                    type="button"
                    onClick={handleEditSupplier}
                    className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    <Edit className="h-4 w-4 mr-1" />
                    Modificar
                  </button>
                </div>
              </div>
            )}

            {formData.payment_method === 'bank_deposit' && (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Banco
                  </label>
                  <select
                    name="bank"
                    value={formData.bank}
                    onChange={handleChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="">Seleccione un banco</option>
                    {bankAccounts.map(account => (
                      <option key={account.id} value={account.bank}>
                        {account.bank}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Cuenta Bancaria
                  </label>
                  <div className="mt-1 flex items-center space-x-2">
                    <input
                      type="text"
                      value={selectedBankAccount?.account_number || ''}
                      disabled
                      className="block w-full rounded-md border-gray-300 bg-gray-50 shadow-sm"
                      placeholder="No hay cuenta seleccionada"
                    />
                    <button
                      type="button"
                      onClick={handleEditSupplier}
                      className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      <Edit className="h-4 w-4 mr-1" />
                      Modificar información bancaria
                    </button>
                  </div>
                </div>

                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Titular de la cuenta
                  </label>
                  <input
                    type="text"
                    value={selectedBankAccount?.account_holder || ''}
                    disabled
                    className="mt-1 block w-full rounded-md border-gray-300 bg-gray-50 shadow-sm"
                    placeholder="No hay cuenta seleccionada"
                  />
                </div>
              </>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Fecha de pago
              </label>
              <input
                type="date"
                name="payment_date"
                value={formData.payment_date}
                onChange={handleChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Fecha de vencimiento
              </label>
              <input
                type="date"
                name="due_date"
                value={formData.due_date}
                onChange={handleChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-gray-900">Cronograma de pago</h3>
              {paymentSchedule.length < 4 && (
                <button
                  type="button"
                  onClick={addPaymentScheduleItem}
                  className="inline-flex items-center px-3 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
                >
                  Agregar pago
                </button>
              )}
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      # DE PAGO
                    </th>
                    <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      %
                    </th>
                    <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      IMPORTE A PAGAR (S/)
                    </th>
                    <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      FECHA DE PAGO
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {paymentSchedule.map((item, index) => (
                    <tr key={index}>
                      <td className="px-3 py-4 whitespace-nowrap text-sm text-gray-900">
                        {item.payment_number}° Pago
                      </td>
                      <td className="px-3 py-4 whitespace-nowrap">
                        <input
                          type="number"
                          value={item.percentage}
                          onChange={(e) => updatePaymentSchedule(index, 'percentage', parseFloat(e.target.value) || 0)}
                          min="0"
                          max="100"
                          step="0.01"
                          className="block w-24 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                        />
                      </td>
                      <td className="px-3 py-4 whitespace-nowrap text-sm text-gray-500">
                        {item.amount_pen.toFixed(2)}
                      </td>
                      <td className="px-3 py-4 whitespace-nowrap">
                        <input
                          type="date"
                          value={item.payment_date}
                          onChange={(e) => updatePaymentSchedule(index, 'payment_date', e.target.value)}
                          className="block rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={loading}
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
            >
              <Save className="h-4 w-4 mr-2" />
              Guardar
            </button>
          </div>
        </form>

        {showEditSupplierForm && supplierDetails && (
          <SupplierForm
            supplier={{
              id: purchaseOrder.supplier.id,
              code: supplierDetails.code,
              name: supplierDetails.name,
              tax_id: supplierDetails.tax_id,
              address: supplierDetails.address,
              phone: supplierDetails.phone,
              email: supplierDetails.email,
              website: supplierDetails.website,
              contact_name: supplierDetails.contact_name,
              contact_phone: supplierDetails.contact_phone,
              contact_email: supplierDetails.contact_email,
              main_payment_method: supplierDetails.main_payment_method,
              mobile_payment_number: supplierDetails.mobile_payment_number,
              product_line: supplierDetails.product_line
            }}
            isEditing={true}
            onClose={() => setShowEditSupplierForm(false)}
            onSave={handleSupplierSaved}
          />
        )}
      </div>
    </div>
  );
}