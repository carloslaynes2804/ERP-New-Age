import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { Plus, Edit, CreditCard, XCircle, AlertCircle, History, Clock, CheckCircle2, Calendar } from 'lucide-react';
import { PaymentOrderForm } from './PaymentOrderForm';

interface PurchaseOrdersListProps {
  onNewOrder: () => void;
  onEditOrder: (orderId: string) => void;
  refreshTrigger?: number;
}

interface PurchaseOrder {
  id: string;
  number: number;
  date: string;
  supplier: {
    name: string;
  };
  supplier_id: string;
  payment_type: string;
  currency: string;
  total: number;
  display_payment_type: string;
  display_currency: string;
  display_total: number;
  status: string;
  approval_status: string | null;
  created_by: string;
  created_at: string;
  updated_at: string;
  user: {
    display_name: string;
  };
}

interface User {
  id: string;
  display_name: string;
}

interface ModificationHistory {
  id: string;
  created_at: string;
  field_name: string;
  old_value: string;
  new_value: string;
  modifier_name: string;
  modification_group: string;
}

interface GroupedModifications {
  id: string;
  date: string;
  time: string;
  modifier: string;
  changes: ModificationHistory[];
  sequence: number;
}

export function PurchaseOrdersList({ onNewOrder, onEditOrder, refreshTrigger = 0 }: PurchaseOrdersListProps) {
  const [orders, setOrders] = useState<PurchaseOrder[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCancelConfirmation, setShowCancelConfirmation] = useState(false);
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [selectedOrderForHistory, setSelectedOrderForHistory] = useState<PurchaseOrder | null>(null);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [modificationHistory, setModificationHistory] = useState<ModificationHistory[]>([]);
  const [groupedModifications, setGroupedModifications] = useState<GroupedModifications[]>([]);
  const [showPaymentOrderForm, setShowPaymentOrderForm] = useState(false);
  const [selectedOrderForPayment, setSelectedOrderForPayment] = useState<PurchaseOrder | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [filters, setFilters] = useState({
    month: new Date().getMonth() + 1,
    year: new Date().getFullYear(),
    responsible: '',
    status: ''
  });

  useEffect(() => {
    loadOrders();
    loadUsers();
  }, [filters, refreshTrigger]);

  const loadUsers = async () => {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('id, display_name')
        .order('display_name');

      if (error) throw error;
      setUsers(data || []);
    } catch (error) {
      console.error('Error loading users:', error);
    }
  };

  const loadOrders = async () => {
    try {
      setLoading(true);
      
      let query = supabase
        .from('purchase_orders_with_values')
        .select(`
          id,
          number,
          date,
          supplier:suppliers(name),
          supplier_id,
          payment_type,
          currency,
          total,
          display_payment_type,
          display_currency,
          display_total,
          status,
          approval_status,
          created_by,
          created_at,
          updated_at,
          user:users!purchase_orders_created_by_fkey(display_name)
        `)
        .order('date', { ascending: false });

      if (filters.month && filters.year) {
        const startDate = `${filters.year}-${String(filters.month).padStart(2, '0')}-01`;
        const endDate = `${filters.year}-${String(filters.month).padStart(2, '0')}-31`;
        query = query.gte('date', startDate).lte('date', endDate);
      }

      if (filters.responsible) {
        query = query.eq('created_by', filters.responsible);
      }

      if (filters.status) {
        query = query.eq('status', filters.status);
      }

      const { data, error } = await query;

      if (error) throw error;
      setOrders(data || []);
    } catch (error) {
      console.error('Error loading orders:', error);
      setError('Error al cargar las órdenes de compra');
    } finally {
      setLoading(false);
    }
  };

  const loadModificationHistory = async (orderId: string) => {
    try {
      setLoadingHistory(true);
      
      // First get the order creation details
      const { data: orderData, error: orderError } = await supabase
        .from('purchase_orders')
        .select(`
          created_at,
          created_by_user:users!purchase_orders_created_by_fkey(display_name)
        `)
        .eq('id', orderId)
        .single();

      if (orderError) throw orderError;

      // Then get modification history
      const { data: modData, error: modError } = await supabase
        .from('purchase_order_modifications_with_users')
        .select('*')
        .eq('purchase_order_id', orderId)
        .order('created_at', { ascending: true });

      if (modError) throw modError;
      
      const modifications = modData || [];

      // Group modifications by modification_group
      const grouped = modifications.reduce<{ [key: string]: ModificationHistory[] }>((acc, mod) => {
        const key = mod.modification_group;
        if (!acc[key]) {
          acc[key] = [];
        }
        acc[key].push(mod);
        return acc;
      }, {});

      // Convert to array and add sequence numbers
      const groupedArray = Object.entries(grouped).map(([key, changes]) => {
        const timestamp = new Date(changes[0].created_at);
        return {
          id: key,
          date: timestamp.toLocaleDateString(),
          time: timestamp.toLocaleTimeString(),
          modifier: changes[0].modifier_name,
          changes,
          sequence: 0
        };
      });

      // Sort by date and time, oldest first
      groupedArray.sort((a, b) => {
        const dateA = new Date(`${a.date} ${a.time}`);
        const dateB = new Date(`${b.date} ${b.time}`);
        return dateA.getTime() - dateB.getTime();
      });

      // Add sequence numbers after sorting
      const sequencedArray = groupedArray.map((group, index) => ({
        ...group,
        sequence: index + 1
      }));

      setGroupedModifications(sequencedArray);
    } catch (error) {
      console.error('Error loading modification history:', error);
      setError('Error al cargar el historial de modificaciones');
    } finally {
      setLoadingHistory(false);
    }
  };

  const handleFilterChange = (name: string, value: string | number) => {
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleViewHistory = async (order: PurchaseOrder) => {
    setSelectedOrderForHistory(order);
    setShowHistoryModal(true);
    await loadModificationHistory(order.id);
  };

  const handleGeneratePaymentOrder = (orderId: string) => {
    const order = orders.find(o => o.id === orderId);
    if (!order) return;

    setShowPaymentOrderForm(true);
    setSelectedOrderForPayment(order);
  };

  const handleCancelOrder = async () => {
    if (!selectedOrderId) return;

    try {
      const { error } = await supabase
        .from('purchase_orders')
        .update({ 
          status: 'cancelled',
          approval_status: 'cancelled',
          updated_at: new Date().toISOString()
        })
        .eq('id', selectedOrderId);

      if (error) throw error;

      setShowCancelConfirmation(false);
      setSelectedOrderId(null);
      loadOrders();
    } catch (error) {
      console.error('Error cancelling order:', error);
      setError('Error al anular la orden');
    }
  };

  const formatFieldName = (fieldName: string): string => {
    const fieldMappings: { [key: string]: string } = {
      payment_type: 'Tipo de pago',
      currency: 'Moneda',
      delivery_location: 'Lugar de entrega',
      observations: 'Observaciones',
      order_reference: 'Número de pedido',
      total: 'Total',
      'items.quantity': 'Cantidad',
      'items.unit_price': 'Precio unitario',
      'items.discount_percent': 'Porcentaje de descuento',
      'items.code': 'Código de producto',
      'items.description': 'Descripción de producto',
      'items.unit': 'Unidad de medida'
    };
    return fieldMappings[fieldName] || fieldName;
  };

  const formatValue = (fieldName: string, value: string): string => {
    if (fieldName === 'payment_type') {
      return value === 'cash' ? 'Contado' : 'Crédito';
    }
    if (fieldName === 'currency') {
      return value === 'PEN' ? 'Soles' : 'Dólares';
    }
    if (fieldName === 'total' || fieldName.includes('price') || fieldName.includes('amount')) {
      return parseFloat(value).toFixed(2);
    }
    return value || '-';
  };

  const getModificationStatus = (order: PurchaseOrder) => {
    if (order.status === 'cancelled') {
      return {
        text: 'Anulada',
        className: 'bg-red-100 text-red-800'
      };
    }

    if (!order.approval_status) {
      return {
        text: 'Sin modificación',
        className: 'bg-gray-100 text-gray-800'
      };
    }

    switch (order.approval_status) {
      case 'pending':
        return {
          text: 'En aprobación',
          className: 'bg-yellow-100 text-yellow-800'
        };
      case 'approved':
        return {
          text: 'Aprobada',
          className: 'bg-green-100 text-green-800'
        };
      case 'rejected':
        return {
          text: 'Rechazada',
          className: 'bg-red-100 text-red-800'
        };
      default:
        return {
          text: 'Sin modificación',
          className: 'bg-gray-100 text-gray-800'
        };
    }
  };

  const isActionDisabled = (order: PurchaseOrder) => {
    return order.status === 'cancelled' || order.approval_status === 'pending';
  };

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="px-4 py-4 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-800">Órdenes de Compra</h2>
          <button
            onClick={onNewOrder}
            className="inline-flex items-center px-3 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <Plus className="h-4 w-4 mr-1" />
            Generar Orden
          </button>
        </div>
      </div>

      <div className="px-4 py-3 border-b border-gray-200 bg-gray-50">
        <div className="grid grid-cols-4 gap-3">
          <div>
            <label className="block text-sm font-medium text-gray-700">Mes</label>
            <select
              value={filters.month}
              onChange={(e) => handleFilterChange('month', parseInt(e.target.value))}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm"
            >
              {Array.from({ length: 12 }, (_, i) => i + 1).map(month => (
                <option key={month} value={month}>
                  {new Date(2000, month - 1).toLocaleString('default', { month: 'long' })}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Año</label>
            <select
              value={filters.year}
              onChange={(e) => handleFilterChange('year', parseInt(e.target.value))}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm"
            >
              {Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i).map(year => (
                <option key={year} value={year}>{year}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Solicitante Logística</label>
            <select
              value={filters.responsible}
              onChange={(e) => handleFilterChange('responsible', e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm"
            >
              <option value="">Todos</option>
              {users.map(user => (
                <option key={user.id} value={user.id}>
                  {user.display_name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Estado de emisión de OC</label>
            <select
              value={filters.status}
              onChange={(e) => handleFilterChange('status', e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm"
            >
              <option value="">Todos</option>
              <option value="generated">Generada</option>
              <option value="cancelled">Anulada</option>
            </select>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-24">
                N° Orden
              </th>
              <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-24">
                Fecha
              </th>
              <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Proveedor
              </th>
              <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Solicitante Logística
              </th>
              <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-28">
                Tipo Pago
              </th>
              <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-20">
                Moneda
              </th>
              <th className="px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider w-28">
                Total
              </th>
              <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-28">
                Estado de emisión de OC
              </th>
              <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-28">
                Modificación
              </th>
              <th className="px-3 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider w-32">
                Acciones
              </th>
              <th className="px-3 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider w-24">
                Historial
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {loading ? (
              <tr>
                <td colSpan={11} className="px-3 py-4 text-center text-sm text-gray-500">
                  Cargando órdenes...
                </td>
              </tr>
            ) : orders.length === 0 ? (
              <tr>
                <td colSpan={11} className="px-3 py-4 text-center text-sm text-gray-500">
                  No se encontraron órdenes de compra
                </td>
              </tr>
            ) : (
              orders.map((order) => {
                const modificationStatus = getModificationStatus(order);
                const isDisabled = isActionDisabled(order);
                return (
                  <tr key={order.id} className="hover:bg-gray-50">
                    <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-900">
                      {order.number.toString().padStart(6, '0')}
                    </td>
                    <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500">
                      {new Date(order.date).toLocaleDateString()}
                    </td>
                    <td className="px-3 py-2 text-sm text-gray-900 truncate max-w-[200px]">
                      {order.supplier.name}
                    </td>
                    <td className="px-3 py-2 text-sm text-gray-900 truncate max-w-[200px]">
                      {order.user.display_name}
                    </td>
                    <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500">
                      {order.display_payment_type === 'cash' ? 'Contado' : 'Crédito'}
                    </td>
                    <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500">
                      {order.display_currency}
                    </td>
                    <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-900 text-right">
                      {order.display_total.toFixed(2)}
                    </td>
                    <td className="px-3 py-2 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        order.status === 'cancelled' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'
                      }`}>
                        {order.status === 'cancelled' ? 'Anulada' : 'Generada'}
                      </span>
                    </td>
                    <td className="px-3 py-2 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${modificationStatus.className}`}>
                        {modificationStatus.text}
                      </span>
                    </td>
                    <td className="px-3 py-2 whitespace-nowrap text-sm font-medium">
                      {order.status !== 'cancelled' ? (
                        <div className="flex justify-center space-x-2">
                          <button
                            onClick={() => onEditOrder(order.id)}
                            disabled={isDisabled}
                            className={`text-blue-600 hover:text-blue-900 relative group ${isDisabled ? 'opacity-50 cursor-not-allowed' : ''}`}
                            title={isDisabled ? 'No se puede modificar mientras está en aprobación' : 'Modificar OC'}
                          >
                            <Edit className="h-4 w-4" />
                            <span className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 text-xs font-medium text-white bg-gray-900 rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap">
                              Modificar OC
                            </span>
                          </button>
                          <button
                            onClick={() => handleGeneratePaymentOrder(order.id)}
                            disabled={isDisabled}
                            className={`text-green-600 hover:text-green-900 relative group ${isDisabled ? 'opacity-50 cursor-not-allowed' : ''}`}
                            title={isDisabled ? 'No se puede generar orden de pago mientras está en aprobación' : 'Generar Orden de pago'}
                          >
                            <CreditCard className="h-4 w-4" />
                            <span className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 text-xs font-medium text-white bg-gray-900 rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap">
                              Generar Orden de pago
                            </span>
                          </button>
                          <button
                            onClick={() => {
                              setSelectedOrderId(order.id);
                              setShowCancelConfirmation(true);
                            }}
                            disabled={isDisabled}
                            className={`text-red-600 hover:text-red-900 relative group ${isDisabled ? 'opacity-50 cursor-not-allowed' : ''}`}
                            title={isDisabled ? 'No se puede anular mientras está en aprobación' : 'Anular Orden de compra'}
                          >
                            <XCircle className="h-4 w-4" />
                            <span className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 text-xs font-medium text-white bg-gray-900 rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap">
                              Anular Orden de compra
                            </span>
                          </button>
                        </div>
                      ) : (
                        <div className="text-center text-gray-400 text-sm">
                          Orden anulada
                        </div>
                      )}
                    </td>
                    <td className="px-3 py-2 whitespace-nowrap text-sm font-medium text-center">
                      <button
                        onClick={() => handleViewHistory(order)}
                        className="text-blue-600 hover:text-blue-900 relative group"
                        title="Ver historial"
                      >
                        <History className="h-5 w-5" />
                        <span className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 text-xs font-medium text-white bg-gray-900 rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap">
                          Ver historial
                        </span>
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {showCancelConfirmation && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-sm w-full">
            <div className="flex items-center mb-4">
              <XCircle className="h-6 w-6 text-red-500 mr-2" />
              <h3 className="text-lg font-medium">Confirmar Anulación</h3>
            </div>
            <p className="text-gray-500 mb-4">
              ¿Está seguro que desea anular esta orden de compra? Esta acción no se puede deshacer.
            </p>
            <div className="flex justify-end space-x-3">
              <button
                type="button"
                onClick={() => {
                  setShowCancelConfirmation(false);
                  setSelectedOrderId(null);
                }}
                className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleCancelOrder}
                className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
              >
                Anular Orden
              </button>
            </div>
          </div>
        </div>
      )}

      {showHistoryModal && selectedOrderForHistory && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h3 className="text-lg font-medium text-gray-900">
                  Historial de modificaciones - OC N° {selectedOrderForHistory.number.toString().padStart(6, '0')}
                </h3>
                <p className="mt-1 text-sm text-gray-500">
                  Proveedor: {selectedOrderForHistory.supplier.name}
                </p>
              </div>
              <button
                onClick={() => {
                  setShowHistoryModal(false);
                  setSelectedOrderForHistory(null);
                  setModificationHistory([]);
                  setGroupedModifications([]);
                }}
                className="text-gray-400 hover:text-gray-500"
              >
                <XCircle className="h-5 w-5" />
              </button>
            </div>

            {loadingHistory ? (
              <div className="text-center py-4">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                <p className="mt-2 text-sm text-gray-500">Cargando historial...</p>
              </div>
            ) : (
              <div className="space-y-8">
                {/* Creation Event */}
                <div className="relative pb-8">
                  <div className="absolute left-4 -ml-px h-full w-0.5 bg-gray-200"></div>
                  <div className="relative flex items-start group">
                    <div className="flex h-8 items-center">
                      <div className="relative z-10 w-8 h-8 flex items-center justify-center bg-blue-100 rounded-full">
                        <Calendar className="h-5 w-5 text-blue-600" />
                      </div>
                    </div>
                    <div className="ml-4 min-w-0 flex-1">
                      <div className="text-sm font-medium text-gray-900">Creación de la orden</div>
                      <div className="mt-1 text-sm text-gray-500">
                        {new Date(selectedOrderForHistory.created_at).toLocaleString()}
                      </div>
                      <div className="mt-1 text-sm text-gray-500">
                        Por: {selectedOrderForHistory.user.display_name}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Modifications */}
                {groupedModifications.map((group) => (
                  <div key={group.id} className="relative pb-8">
                    <div className="absolute left-4 -ml-px h-full w-0.5 bg-gray-200"></div>
                    <div className="relative flex items-start group">
                      <div className="flex h-8 items-center">
                        <div className="relative z-10 w-8 h-8 flex items-center justify-center bg-blue-100 rounded-full">
                          <Clock className="h-5 w-5 text-blue-600" />
                        </div>
                      </div>
                      <div className="ml-4 min-w-0 flex-1">
                        <div className="text-sm font-medium text-gray-900">
                          Modificación {group.sequence}
                        </div>
                        <div className="mt-1 text-sm text-gray-500">
                          {group.date} - {group.time}
                        </div>
                        <div className="mt-1 text-sm text-gray-500">
                          Por: {group.modifier}
                        </div>
                        <div className="mt-2 bg-gray-50 rounded-lg p-4">
                          <table className="min-w-full">
                            <thead>
                              <tr>
                                <th className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider pb-3">
                                  Campo
                                </th>
                                <th className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider pb-3">
                                  Valor anterior
                                </th>
                                <th className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider pb-3">
                                  Nuevo valor
                                </th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                              {group.changes.map((change, index) => (
                                <tr key={change.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                                  <td className="py-2 text-sm font-medium text-gray-900">
                                    {formatFieldName(change.field_name)}
                                  </td>
                                  <td className="py-2 text-sm text-gray-700">
                                    {formatValue(change.field_name, change.old_value)}
                                  </td>
                                  <td className="py-2 text-sm text-gray-700">
                                    {formatValue(change.field_name, change.new_value)}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {showPaymentOrderForm && selectedOrderForPayment && (
        <PaymentOrderForm
          purchaseOrder={{
            id: selectedOrderForPayment.id,
            number: selectedOrderForPayment.number.toString().padStart(6, '0'),
            supplier: {
              id: selectedOrderForPayment.supplier_id,
              name: selectedOrderForPayment.supplier.name
            },
            currency: selectedOrderForPayment.currency,
            total: selectedOrderForPayment.total
          }}
          onClose={() => {
            setShowPaymentOrderForm(false);
            setSelectedOrderForPayment(null);
          }}
          onSave={() => {
            setShowPaymentOrderForm(false);
            setSelectedOrderForPayment(null);
            loadOrders();
          }}
        />
      )}
    </div>
  );
}