import React, { useState, useEffect } from 'react';
import { X, AlertCircle, CheckCircle2, Plus, Trash2 } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface SupplierFormProps {
  supplier?: {
    id: string;
    code: string;
    name: string;
    tax_id?: string;
    address?: string;
    phone?: string;
    website?: string;
    contact_name?: string;
    contact_phone?: string;
    contact_email?: string;
    main_payment_method?: 'bank_deposit' | 'yape' | 'plin' | 'cash';
    mobile_payment_number?: string;
    product_line?: string;
  };
  onClose: () => void;
  onSave: () => void;
  isEditing?: boolean;
}

interface BankAccount {
  bank: 'BCP' | 'Interbank' | 'BBVA' | 'Scotiabank';
  account_number: string;
  cci_number?: string;
  account_holder: string;
}

export function SupplierForm({ supplier, onClose, onSave, isEditing = false }: SupplierFormProps) {
  const [nextCode, setNextCode] = useState<string>('');
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [formData, setFormData] = useState({
    code: supplier?.code || '',
    name: supplier?.name || '',
    tax_id: supplier?.tax_id || '',
    address: supplier?.address || '',
    phone: supplier?.phone || '',
    website: supplier?.website || '',
    contact_name: supplier?.contact_name || '',
    contact_phone: supplier?.contact_phone || '',
    contact_email: supplier?.contact_email || '',
    main_payment_method: supplier?.main_payment_method || 'bank_deposit',
    mobile_payment_number: supplier?.mobile_payment_number || '',
    product_line: supplier?.product_line || 'Merchandising'
  });

  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>([{
    bank: 'BCP',
    account_number: '',
    cci_number: '',
    account_holder: ''
  }]);

  useEffect(() => {
    if (!isEditing) {
      getNextSupplierCode();
    }
  }, [isEditing]);

  const getNextSupplierCode = async () => {
    try {
      const { data, error } = await supabase
        .from('suppliers')
        .select('code')
        .order('code', { ascending: false })
        .limit(1);

      if (error) throw error;

      let nextNumber = 1;
      if (data && data.length > 0) {
        const lastCode = data[0].code;
        const lastNumber = parseInt(lastCode.replace('PROV', ''));
        nextNumber = lastNumber + 1;
      }

      const newCode = `PROV${String(nextNumber).padStart(3, '0')}`;
      setNextCode(newCode);
      setFormData(prev => ({ ...prev, code: newCode }));
    } catch (error) {
      console.error('Error getting next supplier code:', error);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleBankAccountChange = (index: number, field: keyof BankAccount, value: string) => {
    setBankAccounts(prev => {
      const newAccounts = [...prev];
      newAccounts[index] = {
        ...newAccounts[index],
        [field]: value
      };
      return newAccounts;
    });
  };

  const addBankAccount = () => {
    setBankAccounts(prev => [...prev, {
      bank: 'BCP',
      account_number: '',
      cci_number: '',
      account_holder: ''
    }]);
  };

  const removeBankAccount = (index: number) => {
    setBankAccounts(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setShowConfirmation(true);
  };

  const handleConfirmSave = async () => {
    try {
      let supplierId: string;
      
      if (isEditing && supplier) {
        const { error: supplierError } = await supabase
          .from('suppliers')
          .update(formData)
          .eq('id', supplier.id);
          
        if (supplierError) throw supplierError;
        supplierId = supplier.id;
      } else {
        const { data: supplierData, error: supplierError } = await supabase
          .from('suppliers')
          .insert([formData])
          .select();
          
        if (supplierError) throw supplierError;
        supplierId = supplierData[0].id;
      }

      // Save bank accounts information
      const { error: bankError } = await supabase
        .from('supplier_bank_accounts')
        .insert(
          bankAccounts
            .filter(account => account.account_number && account.account_holder)
            .map(account => ({
              supplier_id: supplierId,
              bank: account.bank,
              account_number: account.account_number,
              cci_number: account.cci_number || null,
              account_holder: account.account_holder
            }))
        );

      if (bankError) throw bankError;
      
      onSave();
    } catch (error) {
      console.error('Error saving supplier:', error);
    }
  };

  return (
    <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-medium">
            {isEditing ? 'Modificar Proveedor' : 'Registrar Nuevo Proveedor'}
          </h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-2 gap-6">
            {/* Basic Information */}
            <div className="col-span-2">
              <h4 className="text-sm font-medium text-gray-900 mb-4">Información Básica</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Código
                  </label>
                  <input
                    type="text"
                    name="code"
                    value={formData.code}
                    readOnly
                    className="mt-1 block w-full rounded-md border-gray-300 bg-gray-50 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Nombre
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>

            {/* Company Information */}
            <div className="col-span-2">
              <h4 className="text-sm font-medium text-gray-900 mb-4">Información de la Empresa</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    RUC
                  </label>
                  <input
                    type="text"
                    name="tax_id"
                    value={formData.tax_id}
                    onChange={handleChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Línea de Producto
                  </label>
                  <select
                    name="product_line"
                    value={formData.product_line}
                    onChange={handleChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="Merchandising">Merchandising</option>
                    <option value="Textil">Textil</option>
                    <option value="Imprenta">Imprenta</option>
                    <option value="Otros">Otros</option>
                  </select>
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Dirección
                  </label>
                  <input
                    type="text"
                    name="address"
                    value={formData.address}
                    onChange={handleChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Teléfono
                  </label>
                  <input
                    type="text"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="flex items-center text-sm font-medium text-gray-700">
                    Sitio Web
                    <span className="ml-1 text-sm text-gray-500">(opcional)</span>
                  </label>
                  <input
                    type="url"
                    name="website"
                    value={formData.website}
                    onChange={handleChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>

            {/* Contact Information */}
            <div className="col-span-2">
              <h4 className="text-sm font-medium text-gray-900 mb-4">Información de Contacto</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Nombre del Contacto
                  </label>
                  <input
                    type="text"
                    name="contact_name"
                    value={formData.contact_name}
                    onChange={handleChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Teléfono del Contacto
                  </label>
                  <input
                    type="text"
                    name="contact_phone"
                    value={formData.contact_phone}
                    onChange={handleChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Email del Contacto
                  </label>
                  <input
                    type="email"
                    name="contact_email"
                    value={formData.contact_email}
                    onChange={handleChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>

            {/* Payment Information */}
            <div className="col-span-2">
              <h4 className="text-sm font-medium text-gray-900 mb-4">Información de Pago</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Método de Pago Principal
                  </label>
                  <select
                    name="main_payment_method"
                    value={formData.main_payment_method}
                    onChange={handleChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="bank_deposit">Depósito Bancario</option>
                    <option value="yape">Yape</option>
                    <option value="plin">Plin</option>
                    <option value="cash">Efectivo</option>
                  </select>
                </div>
                <div>
                  <label className="flex items-center text-sm font-medium text-gray-700">
                    Número para Pago Móvil
                    <span className="ml-1 text-sm text-gray-500">(opcional)</span>
                  </label>
                  <input
                    type="text"
                    name="mobile_payment_number"
                    value={formData.mobile_payment_number}
                    onChange={handleChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>

            {/* Bank Information */}
            <div className="col-span-2">
              <div className="flex justify-between items-center mb-4">
                <h4 className="text-sm font-medium text-gray-900">Información Bancaria</h4>
                <button
                  type="button"
                  onClick={addBankAccount}
                  className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Agregar Banco
                </button>
              </div>

              {bankAccounts.map((account, index) => (
                <div key={index} className="mb-6 last:mb-0">
                  <div className="flex justify-between items-center mb-2">
                    <h5 className="text-sm font-medium text-gray-700">
                      {index === 0 ? 'Banco Principal' : `Banco Adicional ${index}`}
                    </h5>
                    {index > 0 && (
                      <button
                        type="button"
                        onClick={() => removeBankAccount(index)}
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Banco
                      </label>
                      <select
                        value={account.bank}
                        onChange={(e) => handleBankAccountChange(index, 'bank', e.target.value as BankAccount['bank'])}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      >
                        <option value="BCP">BCP</option>
                        <option value="Interbank">Interbank</option>
                        <option value="BBVA">BBVA</option>
                        <option value="Scotiabank">Scotiabank</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Número de Cuenta
                      </label>
                      <input
                        type="text"
                        value={account.account_number}
                        onChange={(e) => handleBankAccountChange(index, 'account_number', e.target.value)}
                        required
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="flex items-center text-sm font-medium text-gray-700">
                        Número CCI
                        <span className="ml-1 text-sm text-gray-500">(opcional)</span>
                      </label>
                      <input
                        type="text"
                        value={account.cci_number}
                        onChange={(e) => handleBankAccountChange(index, 'cci_number', e.target.value)}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Titular de la Cuenta
                      </label>
                      <input
                        type="text"
                        value={account.account_holder}
                        onChange={(e) => handleBankAccountChange(index, 'account_holder', e.target.value)}
                        required
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              {isEditing ? 'Guardar Cambios' : 'Registrar Proveedor'}
            </button>
          </div>
        </form>

        {/* Confirmation Modal */}
        {showConfirmation && (
          <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 max-w-sm w-full">
              <div className="flex items-center mb-4">
                <CheckCircle2 className="h-6 w-6 text-green-500 mr-2" />
                <h3 className="text-lg font-medium">Confirmar Registro</h3>
              </div>
              <p className="text-gray-500 mb-4">
                ¿Está seguro que desea {isEditing ? 'actualizar' : 'registrar'} este proveedor?
              </p>
              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setShowConfirmation(false)}
                  className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleConfirmSave}
                  className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                >
                  Confirmar
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}