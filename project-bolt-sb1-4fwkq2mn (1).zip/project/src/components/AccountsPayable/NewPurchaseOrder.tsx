import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { X, Search, Plus, Trash2, AlertCircle, UserPlus, Edit } from 'lucide-react';
import { SupplierForm } from './SupplierForm';

interface NewPurchaseOrderProps {
  onClose: () => void;
  onOrderCreated?: () => void;
}

interface Supplier {
  id: string;
  code: string;
  name: string;
  product_line?: string;
  tax_id?: string;
  address?: string;
  website?: string;
  contact_name?: string;
  contact_phone?: string;
  contact_email?: string;
  main_payment_method?: 'bank_deposit' | 'yape' | 'plin' | 'cash';
  mobile_payment_number?: string;
}

interface SupplierBankAccount {
  id?: string;
  bank: 'BCP' | 'Interbank' | 'BBVA' | 'Scotiabank';
  account_number: string;
  cci_number: string;
  account_holder: string;
}

interface PurchaseOrderItem {
  id?: string;
  code: string;
  description: string;
  unit: string;
  quantity: number;
  unit_price: number;
  discount_percent: number;
  discount_amount: number;
  subtotal: number;
}

interface User {
  id: string;
  display_name: string;
}

export default function NewPurchaseOrder({ onClose, onOrderCreated }: NewPurchaseOrderProps) {
  const [orderNumber, setOrderNumber] = useState<number | null>(null);
  const [date] = useState<string>(new Date().toISOString().split('T')[0]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [selectedSupplier, setSelectedSupplier] = useState<Supplier | null>(null);
  const [selectedSupplierInTable, setSelectedSupplierInTable] = useState<Supplier | null>(null);
  const [showSupplierSearch, setShowSupplierSearch] = useState(false);
  const [showNewSupplierForm, setShowNewSupplierForm] = useState(false);
  const [showEditSupplierForm, setShowEditSupplierForm] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [supplierSearchTerm, setSupplierSearchTerm] = useState('');
  const [paymentType, setPaymentType] = useState<'cash' | 'credit'>('cash');
  const [currency, setCurrency] = useState<'PEN' | 'USD'>('PEN');
  const [includesIGV, setIncludesIGV] = useState(false);
  const [deliveryLocation, setDeliveryLocation] = useState('');
  const [observations, setObservations] = useState('');
  const [orderReference, setOrderReference] = useState('');
  const [items, setItems] = useState<PurchaseOrderItem[]>([]);
  const [taxRate] = useState(0.18);
  const [currentUser, setCurrentUser] = useState<{ id: string; displayName: string } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [selectedAdvisor, setSelectedAdvisor] = useState<string>('');

  useEffect(() => {
    const getNextOrderNumber = async () => {
      const { data, error } = await supabase
        .from('purchase_orders')
        .select('number')
        .order('number', { ascending: false })
        .limit(1);

      if (!error && data) {
        setOrderNumber((data[0]?.number || 0) + 1);
      }
    };

    const getCurrentUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data: userData } = await supabase
          .from('users')
          .select('display_name')
          .eq('id', user.id)
          .single();

        setCurrentUser({ 
          id: user.id, 
          displayName: userData?.display_name || 'Usuario'
        });
      }
    };

    const loadUsers = async () => {
      try {
        const { data, error } = await supabase
          .from('users')
          .select('id, display_name')
          .order('display_name');

        if (error) throw error;
        setUsers(data || []);
      } catch (error) {
        console.error('Error loading users:', error);
      }
    };

    getNextOrderNumber();
    getCurrentUser();
    loadUsers();
  }, []);

  const searchSuppliers = async (term: string) => {
    const { data } = await supabase
      .from('suppliers')
      .select('*')
      .or(`name.ilike.%${term}%,code.ilike.%${term}%`)
      .limit(10);

    if (data) {
      setSuppliers(data);
    }
  };

  const selectSupplier = (supplier: Supplier) => {
    setSelectedSupplier(supplier);
    setSelectedSupplierInTable(null);
    setShowSupplierSearch(false);
  };

  const handleEditSupplier = (supplier: Supplier) => {
    setSelectedSupplier(supplier);
    setSelectedSupplierInTable(null);
    setShowEditSupplierForm(true);
    setShowSupplierSearch(false);
  };

  const handleSupplierSaved = async () => {
    setShowNewSupplierForm(false);
    setShowEditSupplierForm(false);
    await searchSuppliers(supplierSearchTerm);
  };

  const addItem = () => {
    setItems([
      ...items,
      {
        code: '',
        description: '',
        unit: 'UNID',
        quantity: 0,
        unit_price: 0,
        discount_percent: 0,
        discount_amount: 0,
        subtotal: 0,
      },
    ]);
  };

  const updateItem = (index: number, field: keyof PurchaseOrderItem, value: any) => {
    const newItems = [...items];
    newItems[index] = {
      ...newItems[index],
      [field]: value,
    };

    if (field === 'quantity' || field === 'unit_price' || field === 'discount_percent') {
      const quantity = parseFloat(newItems[index].quantity.toString());
      const unitPrice = parseFloat(newItems[index].unit_price.toString());
      const discountPercent = parseFloat(newItems[index].discount_percent.toString());
      
      const subtotalBeforeDiscount = quantity * unitPrice;
      const discountAmount = (subtotalBeforeDiscount * discountPercent) / 100;
      newItems[index].discount_amount = discountAmount;
      newItems[index].subtotal = subtotalBeforeDiscount - discountAmount;
    }

    setItems(newItems);
  };

  const removeItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const handleGenerateOrder = () => {
    if (!selectedSupplier) {
      setError('Por favor seleccione un proveedor');
      return;
    }

    if (!selectedAdvisor) {
      setError('Por favor seleccione un asesor comercial');
      return;
    }

    if (items.length === 0) {
      setError('Por favor agregue al menos un ítem a la orden');
      return;
    }

    if (items.some(item => !item.code || !item.description || item.quantity <= 0 || item.unit_price <= 0)) {
      setError('Por favor complete todos los campos requeridos en los ítems');
      return;
    }

    setError(null);
    setShowConfirmation(true);
  };

  const handleConfirmOrder = async (generatePaymentOrder: boolean) => {
    setShowConfirmation(false);
    
    try {
      if (!selectedSupplier || !selectedAdvisor) {
        throw new Error('Missing required data');
      }

      const { subtotal, taxAmount, total } = calculateTotals();

      const { data: orderData, error: orderError } = await supabase
        .from('purchase_orders')
        .insert([{
          supplier_id: selectedSupplier.id,
          date,
          payment_type: paymentType,
          currency,
          delivery_location: deliveryLocation || null,
          observations: observations || null,
          order_reference: orderReference || null,
          subtotal,
          tax_rate: taxRate,
          tax_amount: taxAmount,
          total,
          created_by: selectedAdvisor
        }])
        .select()
        .single();

      if (orderError) throw orderError;

      const { error: itemsError } = await supabase
        .from('purchase_order_items')
        .insert(
          items.map(item => ({
            purchase_order_id: orderData.id,
            ...item
          }))
        );

      if (itemsError) throw itemsError;

      if (generatePaymentOrder) {
        // Navigate to payment order module
        // This will be implemented later
      }

      if (onOrderCreated) {
        onOrderCreated();
      }

      onClose();
    } catch (error) {
      console.error('Error creating purchase order:', error);
      setError('Error al crear la orden de compra');
    }
  };

  const resetForm = () => {
    setSelectedSupplier(null);
    setPaymentType('cash');
    setCurrency('PEN');
    setIncludesIGV(false);
    setDeliveryLocation('');
    setObservations('');
    setOrderReference('');
    setItems([]);
    setSelectedAdvisor('');
  };

  const calculateTotals = () => {
    const subtotal = items.reduce((sum, item) => sum + item.subtotal, 0);
    const taxAmount = subtotal * taxRate;
    const total = subtotal + taxAmount;

    return { subtotal, taxAmount, total };
  };

  const { subtotal, taxAmount, total } = calculateTotals();

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="p-6 border-b border-gray-200 flex justify-between items-center">
        <h2 className="text-xl font-semibold text-gray-800">Nueva Orden de Compra</h2>
        <button
          onClick={onClose}
          className="text-gray-400 hover:text-gray-500"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border-l-4 border-red-400">
          <div className="flex">
            <AlertCircle className="h-5 w-5 text-red-400" />
            <p className="ml-3 text-sm text-red-700">{error}</p>
          </div>
        </div>
      )}

      <div className="p-6 border-b border-gray-200">
        <div className="grid grid-cols-2 gap-6">
          <div>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700">N° Orden de Compra</label>
              <input
                type="text"
                value={orderNumber || ''}
                disabled
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 bg-gray-50"
              />
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700">Fecha</label>
              <input
                type="date"
                value={date}
                disabled
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 bg-gray-50"
              />
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700">Tipo de Pago</label>
              <select
                value={paymentType}
                onChange={(e) => setPaymentType(e.target.value as 'cash' | 'credit')}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="cash">Contado</option>
                <option value="credit">Crédito</option>
              </select>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700">Moneda</label>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value as 'PEN' | 'USD')}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="PEN">Soles (PEN)</option>
                <option value="USD">Dólares (USD)</option>
              </select>
            </div>

            <div className="mb-4">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={includesIGV}
                  onChange={(e) => setIncludesIGV(e.target.checked)}
                  className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50"
                />
                <span className="ml-2 text-sm text-gray-700">Precio incluye IGV</span>
              </label>
            </div>
          </div>

          <div>
            <div className="mb-4 relative">
              <label className="block text-sm font-medium text-gray-700">Proveedor</label>
              <div className="mt-1 flex space-x-2">
                <div className="relative flex-1">
                  <input
                    type="text"
                    value={selectedSupplier ? selectedSupplier.name : ''}
                    onClick={() => setShowSupplierSearch(true)}
                    readOnly
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 cursor-pointer"
                    placeholder="Buscar proveedor..."
                  />
                  {selectedSupplier && (
                    <button
                      type="button"
                      onClick={() => setShowEditSupplierForm(true)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      <Search className="h-5 w-5" />
                    </button>
                  )}
                </div>
              </div>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700">Código de Proveedor</label>
              <input
                type="text"
                value={selectedSupplier?.code || ''}
                readOnly
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 bg-gray-50"
              />
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700">Asesor Comercial</label>
              <select
                value={selectedAdvisor}
                onChange={(e) => setSelectedAdvisor(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="">Seleccione un asesor</option>
                {users.map(user => (
                  <option key={user.id} value={user.id}>
                    {user.display_name}
                  </option>
                ))}
              </select>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700">Lugar de Entrega</label>
              <input
                type="text"
                value={deliveryLocation}
                onChange={(e) => setDeliveryLocation(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700">Observaciones</label>
              <textarea
                value={observations}
                onChange={(e) => setObservations(e.target.value)}
                rows={3}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700">Número de pedido</label>
              <input
                type="text"
                value={orderReference}
                onChange={(e) => setOrderReference(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium text-gray-900">Ítems</h3>
          <button
            type="button"
            onClick={addItem}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <Plus className="h-4 w-4 mr-2" />
            Agregar Ítem
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead>
              <tr>
                <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Código</th>
                <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Descripción</th>
                <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Unidad</th>
                <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cantidad</th>
                <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Precio Unit.</th>
                <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Desc. %</th>
                <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Desc. Monto</th>
                <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subtotal</th>
                <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"></th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {items.map((item, index) => (
                <tr key={index}>
                  <td className="px-3 py-4 whitespace-nowrap">
                    <input
                      type="text"
                      value={item.code}
                      onChange={(e) => updateItem(index, 'code', e.target.value)}
                      className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                  </td>
                  <td className="px-3 py-4 whitespace-nowrap">
                    <input
                      type="text"
                      value={item.description}
                      onChange={(e) => updateItem(index, 'description', e.target.value)}
                      className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                  </td>
                  <td className="px-3 py-4 whitespace-nowrap">
                    <input
                      type="text"
                      value={item.unit}
                      onChange={(e) => updateItem(index, 'unit', e.target.value)}
                      className="block w-40 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                  </td>
                  <td className="px-3 py-4 whitespace-nowrap">
                    <input
                      type="number"
                      value={item.quantity || ''}
                      onChange={(e) => updateItem(index, 'quantity', parseFloat(e.target.value) || 0)}
                      className="block w-24 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                  </td>
                  <td className="px-3 py-4 whitespace-nowrap">
                    <input
                      type="number"
                      value={item.unit_price || ''}
                      onChange={(e) => updateItem(index, 'unit_price', parseFloat(e.target.value) || 0)}
                      className="block w-32 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                  </td>
                  <td className="px-3 py-4 whitespace-nowrap">
                    <input
                      type="number"
                      value={item.discount_percent || ''}
                      onChange={(e) => updateItem(index, 'discount_percent', parseFloat(e.target.value) || 0)}
                      className="block w-24 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                  </td>
                  <td className="px-3 py-4 whitespace-nowrap">
                    <input
                      type="number"
                      value={item.discount_amount || ''}
                      disabled
                      className="block w-32 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm bg-gray-50"
                    />
                  </td>
                  <td className="px-3 py-4 whitespace-nowrap">
                    <input
                      type="number"
                      value={item.subtotal || ''}
                      disabled
                      className="block w-32 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm bg-gray-50"
                    />
                  </td>
                  <td className="px-3 py-4 whitespace-nowrap">
                    <button
                      type="button"
                      onClick={() => removeItem(index)}
                      className="text-red-600 hover:text-red-900"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-8 flex justify-end">
          <div className="w-80">
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-500">Subtotal:</span>
                <span className="text-sm font-medium text-gray-900">{currency} {subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-500">IGV ({(taxRate * 100).toFixed(0)}%):</span>
                <span className="text-sm font-medium text-gray-900">{currency} {taxAmount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center pt-2 border-t border-gray-200">
                <span className="text-base font-medium text-gray-900">Total:</span>
                <span className="text-base font-medium text-gray-900">{currency} {total.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex justify-end space-x-3">
        <button
          type="button"
          onClick={onClose}
          className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          Cancelar
        </button>
        <button
          type="button"
          onClick={handleGenerateOrder}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          Generar Orden de Compra
        </button>
      </div>

      {showSupplierSearch && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-2xl w-full">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium">Buscar Proveedor</h3>
              <button
                onClick={() => setShowSupplierSearch(false)}
                className="text-gray-400 hover:text-gray-500"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="mb-4">
              <div className="flex space-x-2">
                <div className="flex-1">
                  <input
                    type="text"
                    value={supplierSearchTerm}
                    onChange={(e) => {
                      setSupplierSearchTerm(e.target.value);
                      searchSuppliers(e.target.value);
                    }}
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    placeholder="Buscar por nombre o código..."
                  />
                </div>
                <div className="flex space-x-2">
                  <button
                    type="button"
                    onClick={() => setShowNewSupplierForm(true)}
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    <UserPlus className="h-4 w-4 mr-2" />
                    Registrar Nuevo
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (selectedSupplierInTable) {
                        handleEditSupplier(selectedSupplierInTable);
                      }
                    }}
                    disabled={!selectedSupplierInTable}
                    className={`inline-flex items-center px-4 py-2 border text-sm font-medium rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${
                      selectedSupplierInTable
                        ? 'border-transparent text-white bg-blue-600 hover:bg-blue-700'
                        : 'border-gray-300 text-gray-400 bg-gray-100 cursor-not-allowed'
                    }`}
                  >
                    <Edit className="h-4 w-4 mr-2" />
                    Modificar Proveedor
                  </button>
                </div>
              </div>
            </div>
            <div className="overflow-y-auto max-h-96">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nombre</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Línea</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {suppliers.map((supplier) => (
                    <tr 
                      key={supplier.id} 
                      className={`hover:bg-gray-50 cursor-pointer ${
                        selectedSupplierInTable?.id === supplier.id ? 'bg-blue-50' : ''
                      }`}
                      onClick={() => setSelectedSupplierInTable(supplier)}
                    >
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{supplier.name}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{supplier.product_line}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex space-x-2 justify-end">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              selectSupplier(supplier);
                            }}
                            className="text-blue-600 hover:text-blue-900"
                          >
                            Seleccionar
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleEditSupplier(supplier);
                            }}
                            className="text-gray-600 hover:text-gray-900"
                          >
                            <Edit className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {showNewSupplierForm && (
        <SupplierForm
          onClose={() => setShowNewSupplierForm(false)}
          onSave={handleSupplierSaved}
        />
      )}

      {showEditSupplierForm && selectedSupplier && (
        <SupplierForm
          supplier={selectedSupplier}
          isEditing={true}
          onClose={() => setShowEditSupplierForm(false)}
          onSave={handleSupplierSaved}
        />
      )}

      {showConfirmation && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-lg w-full">
            <div className="flex items-center mb-4">
              <AlertCircle className="h-6 w-6 text-blue-500 mr-2" />
              <h3 className="text-lg font-medium">Confirmar Orden de Compra</h3>
            </div>
            <p className="text-gray-500 mb-4">
              La orden de compra se generará con los datos ingresados. ¿Desea generar también una orden de pago?
            </p>
            <div className="flex justify-end space-x-3">
              <button
                type="button"
                onClick={() => handleConfirmOrder(false)}
                className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Continuar sin orden de pago
              </button>
              <button
                type="button"
                onClick={() => handleConfirmOrder(true)}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Generar Orden de pago
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}