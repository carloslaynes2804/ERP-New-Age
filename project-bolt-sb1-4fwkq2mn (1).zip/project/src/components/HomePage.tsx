import React, { useEffect, useState } from 'react';
import { FileText, DollarSign, PiggyBank, BarChart, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { getUserRoles, UserRole, hasAccess, SECTION_ROLES } from '../lib/auth';

export function HomePage() {
  const [roles, setRoles] = useState<UserRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    async function loadUserRoles() {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          const userRoles = await getUserRoles(user);
          setRoles(userRoles);
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An error occurred while fetching user roles');
      } finally {
        setLoading(false);
      }
    }

    loadUserRoles();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center">
            <AlertCircle className="h-5 w-5 text-red-500 mr-2" />
            <p className="text-red-700">{error}</p>
          </div>
        </div>
      </div>
    );
  }

  const canAccessPayable = hasAccess(roles, 'logistics');
  const canAccessReceivable = hasAccess(roles, 'sales');
  const canAccessFinance = hasAccess(roles, 'finance');
  const canAccessManagement = roles.includes('management');

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 sm:text-4xl">
            Sistema de Control Financiero
          </h1>
          <p className="mt-3 max-w-2xl mx-auto text-xl text-gray-500 sm:mt-4">
            Seleccione una opción para comenzar
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {/* Cuentas por Pagar */}
          <div className="relative group">
            <div className={`relative h-80 w-full overflow-hidden rounded-lg bg-white ${
              canAccessPayable ? 'group-hover:opacity-75' : 'opacity-50'
            } sm:aspect-w-2 sm:aspect-h-1 sm:h-64 lg:aspect-w-1 lg:aspect-h-1`}>
              <div className="h-full w-full flex flex-col items-center justify-center p-8 transition-all duration-300 group-hover:bg-blue-50">
                <FileText className="h-16 w-16 text-blue-600 mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 text-center">
                  Cuentas por pagar
                </h3>
                <p className="mt-4 text-base text-gray-500 text-center">
                  Solicitud de pagos a proveedores
                </p>
                {!canAccessPayable && (
                  <div className="absolute inset-0 bg-white bg-opacity-90 flex items-center justify-center">
                    <div className="text-center p-4">
                      <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-2" />
                      <p className="text-sm text-red-600">Acceso no autorizado</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
            <button
              onClick={() => canAccessPayable && navigate('/accounts-payable')}
              disabled={!canAccessPayable}
              className={`mt-4 w-full inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white ${
                canAccessPayable
                  ? 'bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500'
                  : 'bg-gray-400 cursor-not-allowed'
              }`}
            >
              Cuentas por pagar
            </button>
          </div>

          {/* Cuentas por Cobrar */}
          <div className="relative group">
            <div className={`relative h-80 w-full overflow-hidden rounded-lg bg-white ${
              canAccessReceivable ? 'group-hover:opacity-75' : 'opacity-50'
            } sm:aspect-w-2 sm:aspect-h-1 sm:h-64 lg:aspect-w-1 lg:aspect-h-1`}>
              <div className="h-full w-full flex flex-col items-center justify-center p-8 transition-all duration-300 group-hover:bg-green-50">
                <DollarSign className="h-16 w-16 text-green-600 mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 text-center">
                  Cuentas por cobrar
                </h3>
                <p className="mt-4 text-base text-gray-500 text-center">
                  Solicitud de facturación y seguimiento de cobros
                </p>
                {!canAccessReceivable && (
                  <div className="absolute inset-0 bg-white bg-opacity-90 flex items-center justify-center">
                    <div className="text-center p-4">
                      <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-2" />
                      <p className="text-sm text-red-600">Acceso no autorizado</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
            <button
              onClick={() => canAccessReceivable && navigate('/accounts-receivable')}
              disabled={!canAccessReceivable}
              className={`mt-4 w-full inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white ${
                canAccessReceivable
                  ? 'bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500'
                  : 'bg-gray-400 cursor-not-allowed'
              }`}
            >
              Cuentas por cobrar
            </button>
          </div>

          {/* Control Finanzas */}
          <div className="relative group">
            <div className={`relative h-80 w-full overflow-hidden rounded-lg bg-white ${
              canAccessFinance ? 'group-hover:opacity-75' : 'opacity-50'
            } sm:aspect-w-2 sm:aspect-h-1 sm:h-64 lg:aspect-w-1 lg:aspect-h-1`}>
              <div className="h-full w-full flex flex-col items-center justify-center p-8 transition-all duration-300 group-hover:bg-purple-50">
                <PiggyBank className="h-16 w-16 text-purple-600 mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 text-center">
                  Control Finanzas
                </h3>
                <p className="mt-4 text-base text-gray-500 text-center">
                  Gestión financiera
                </p>
                {!canAccessFinance && (
                  <div className="absolute inset-0 bg-white bg-opacity-90 flex items-center justify-center">
                    <div className="text-center p-4">
                      <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-2" />
                      <p className="text-sm text-red-600">Acceso no autorizado</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
            <button
              onClick={() => canAccessFinance && navigate('/finance-control')}
              disabled={!canAccessFinance}
              className={`mt-4 w-full inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white ${
                canAccessFinance
                  ? 'bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500'
                  : 'bg-gray-400 cursor-not-allowed'
              }`}
            >
              Control Finanzas
            </button>
          </div>

          {/* Gerencia General */}
          <div className="relative group">
            <div className={`relative h-80 w-full overflow-hidden rounded-lg bg-white ${
              canAccessManagement ? 'group-hover:opacity-75' : 'opacity-50'
            } sm:aspect-w-2 sm:aspect-h-1 sm:h-64 lg:aspect-w-1 lg:aspect-h-1`}>
              <div className="h-full w-full flex flex-col items-center justify-center p-8 transition-all duration-300 group-hover:bg-amber-50">
                <BarChart className="h-16 w-16 text-amber-600 mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 text-center">
                  Gerencia General
                </h3>
                <p className="mt-4 text-base text-gray-500 text-center">
                  Resultados
                </p>
                {!canAccessManagement && (
                  <div className="absolute inset-0 bg-white bg-opacity-90 flex items-center justify-center">
                    <div className="text-center p-4">
                      <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-2" />
                      <p className="text-sm text-red-600">Acceso no autorizado</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
            <button
              onClick={() => canAccessManagement && navigate('/management')}
              disabled={!canAccessManagement}
              className={`mt-4 w-full inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white ${
                canAccessManagement
                  ? 'bg-amber-600 hover:bg-amber-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-500'
                  : 'bg-gray-400 cursor-not-allowed'
              }`}
            >
              Gerencia General
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}